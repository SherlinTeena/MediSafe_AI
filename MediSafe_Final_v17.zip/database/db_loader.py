"""
MediSafe AI — Database Loader
==============================
Handles loading, caching, and querying the medicine database from CSV.
"""

import pandas as pd
import os
import json
from typing import Dict, Optional, List


class MedicineDatabase:
    """
    Singleton-style loader for the medicines CSV.
    Provides lookup, search, and category filtering.
    """

    _instance = None
    _loaded   = False

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance

    def __init__(self):
        if not self._loaded:
            self._data: Dict[str, dict] = {}
            self._df: Optional[pd.DataFrame] = None
            self._loaded = True

    def load(self, csv_path: str) -> bool:
        """Load medicines from CSV into memory."""
        try:
            df = pd.read_csv(csv_path)
            df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
            self._df = df
            for _, row in df.iterrows():
                key = str(row.get('name', '')).strip().lower()
                if key:
                    self._data[key] = {
                        'name':              row.get('name', ''),
                        'category':          row.get('category', ''),
                        'use':               row.get('use', ''),
                        'adult_dose':        float(row.get('adult_dose', 0) or 0),
                        'child_dose':        float(row.get('child_dose', 0) or 0),
                        'elderly_dose':      float(row.get('elderly_dose', 0) or 0),
                        'max_daily':         float(row.get('max_daily', 0) or 0),
                        'side_effects':      row.get('side_effects', ''),
                        'interactions':      row.get('interactions', ''),
                        'contraindications': row.get('contraindications', ''),
                        'food_avoid':        row.get('food_avoid', ''),
                        'food_take':         row.get('food_take', ''),
                        'allergy_warning':   row.get('allergy_warning', ''),
                    }
            return True
        except Exception as e:
            print(f"[DB] Error loading database: {e}")
            return False

    def get(self, name: str) -> Optional[dict]:
        """Get a medicine by name (case-insensitive)."""
        return self._data.get(name.lower().strip())

    def all_names(self) -> List[str]:
        """Return all medicine names (lowercase)."""
        return sorted(self._data.keys())

    def by_category(self, category: str) -> List[dict]:
        """Return all medicines in a given category."""
        return [m for m in self._data.values() if m.get('category', '').lower() == category.lower()]

    def categories(self) -> List[str]:
        """Return all unique categories."""
        return sorted(set(m.get('category', '') for m in self._data.values()))

    def search(self, query: str) -> List[dict]:
        """Fuzzy-ish search on name, category, and use."""
        q = query.lower()
        return [m for m in self._data.values()
                if q in m.get('name', '').lower()
                or q in m.get('category', '').lower()
                or q in m.get('use', '').lower()]

    def count(self) -> int:
        return len(self._data)

    def export_json(self, output_path: str):
        """Export database to JSON file."""
        with open(output_path, 'w') as f:
            json.dump(self._data, f, indent=2)


# Singleton instance
medicine_db = MedicineDatabase()
