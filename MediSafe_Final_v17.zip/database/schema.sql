-- ============================================================
-- MediSafe AI — Medicine Database Schema
-- ============================================================
-- Current implementation uses CSV / Pandas.
-- This schema documents the structure for future SQL migration.
-- ============================================================

CREATE TABLE IF NOT EXISTS medicines (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    name                TEXT NOT NULL UNIQUE,
    category            TEXT NOT NULL,
    use                 TEXT,
    adult_dose          REAL DEFAULT 0,
    child_dose          REAL DEFAULT 0,
    elderly_dose        REAL DEFAULT 0,
    max_daily           REAL DEFAULT 0,
    side_effects        TEXT,
    interactions        TEXT,
    contraindications   TEXT,
    food_avoid          TEXT,
    food_take           TEXT,
    allergy_warning     TEXT,
    created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS check_logs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT,
    patient_name    TEXT,
    medicine_name   TEXT,
    disease         TEXT,
    age             INTEGER,
    weight          REAL,
    gender          TEXT,
    is_safe         BOOLEAN,
    safety_score    INTEGER,
    timestamp       DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS chat_logs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      TEXT,
    medicine_name   TEXT,
    role            TEXT CHECK(role IN ('user', 'bot')),
    message         TEXT,
    intent          TEXT,
    timestamp       DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_medicines_category ON medicines(category);
CREATE INDEX IF NOT EXISTS idx_medicines_name ON medicines(name);
CREATE INDEX IF NOT EXISTS idx_check_logs_medicine ON check_logs(medicine_name);
CREATE INDEX IF NOT EXISTS idx_chat_logs_session ON chat_logs(session_id);
