# MediSafe AI — API Documentation

All endpoints return JSON unless noted otherwise.

---

## Routes

| Method | Route                    | Description                          |
|--------|--------------------------|--------------------------------------|
| GET    | `/`                      | Home / check form page               |
| POST   | `/check_medication`      | Run medication safety check          |
| POST   | `/chatbot`               | AI chatbot query                     |
| POST   | `/generate_prescription` | Generate doctor-style prescription   |
| POST   | `/search_medicine`       | Search medicine by name              |
| GET    | `/about`                 | About page                           |
| GET    | `/dashboard`             | Analytics dashboard                  |
| GET    | `/api/medicines`         | List all medicine names (JSON)       |
| GET    | `/api/medicine/<name>`   | Get medicine details (JSON)          |
| GET    | `/api/stats`             | Database stats (JSON)                |

---

## POST /chatbot

**Request body:**
```json
{
  "question":     "What food should I avoid?",
  "medicine":     "paracetamol",
  "patient_name": "Sherlin",
  "history":      []
}
```

**Response:**
```json
{
  "answer": "🍽️ <strong>Food Guidelines for Paracetamol:</strong>..."
}
```

---

## POST /generate_prescription

**Request body:**
```json
{
  "medicine": "paracetamol",
  "problem":  "Fever and body pain",
  "age":      25,
  "weight":   60
}
```

**Response:**
```json
{
  "prescription": {
    "medicine":             "Paracetamol",
    "category":             "Painkillers",
    "problem":              "Fever and body pain",
    "age_group":            "Adult",
    "dose":                 500,
    "times_per_day":        3,
    "max_daily":            2000,
    "food_timing":          "After meal or with food",
    "food_avoid":           "Alcohol",
    "schedule": [
      {"time":"Morning","icon":"🌅","clock":"8:00 AM","dose":500,"note":"After meal"},
      {"time":"Afternoon","icon":"☀️","clock":"2:00 PM","dose":500,"note":"After meal"},
      {"time":"Night","icon":"🌙","clock":"8:00 PM","dose":500,"note":"After meal"}
    ],
    "duration":             "3–5 days",
    "duration_note":        "Stop if symptoms resolve.",
    "special_instructions": ["💧 Drink a full glass of water with each dose", "⏰ Take at the same time every day"],
    "side_effects":         "Nausea, liver damage in overdose"
  }
}
```

---

## GET /api/stats

**Response:**
```json
{
  "total_medicines": 41,
  "categories": {
    "Painkillers": 5,
    "Antibiotics": 8
  },
  "generated_at": "2024-11-01T10:30:00"
}
```
