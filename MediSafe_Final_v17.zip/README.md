# MediSafe AI — Explainable AI-Based Personalized Medication Safety System

**Developer:** Sherlin  
**Type:** Conference/Academic Project

---

## Setup & Run

```bash
pip install flask pandas
python app.py
```

Then open: **http://localhost:5000**

---

## Project Structure

```
MEDISAFE/
├── app.py              ← Flask backend
├── medicines.csv       ← Medicine database (41 medicines)
├── requirements.txt
├── data/
│   └── medicine_data.json
├── templates/
│   ├── index.html      ← Home page
│   ├── result.html     ← Results & chatbot
│   └── about.html      ← About page
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── chatbot.js
```

---

## Features

- ✅ Drug interaction detection
- ✅ Allergy conflict checking  
- ✅ Personalized dosage (age + weight)
- ✅ Explainable AI reasoning
- ✅ Smart Prescription Generator (morning/afternoon/night)
- ✅ AI Chatbot with voice input
- ✅ Chat history (session storage)
- ✅ File upload
- ✅ Download PDF
- ✅ Safety score with animated progress bar
- ✅ Dark mode app-like UI

---

> ⚠️ For educational purposes only. Not a substitute for medical advice.
