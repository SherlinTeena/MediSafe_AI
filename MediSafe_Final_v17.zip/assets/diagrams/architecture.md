# MediSafe AI — System Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        MEDISAFE AI SYSTEM                       │
├─────────────────────────────────────────────────────────────────┤
│                                                                 │
│   ┌──────────────┐    ┌──────────────┐    ┌─────────────────┐  │
│   │  index.html  │    │  result.html │    │  about / dash   │  │
│   │  (Home Form) │    │  (Result UI) │    │  (Info Pages)   │  │
│   └──────┬───────┘    └──────┬───────┘    └────────┬────────┘  │
│          │                   │                      │           │
│          └───────────────────┴──────────────────────┘           │
│                              │                                  │
│                    ┌─────────▼──────────┐                       │
│                    │   Flask Backend     │                       │
│                    │   (app.py)          │                       │
│                    └─────────┬──────────┘                       │
│                              │                                  │
│        ┌─────────────────────┼─────────────────────┐           │
│        │                     │                     │           │
│   ┌────▼──────┐      ┌───────▼──────┐    ┌────────▼────────┐  │
│   │  Safety   │      │   Chatbot    │    │  Prescription   │  │
│   │  Checker  │      │   Service    │    │   Service       │  │
│   └────┬──────┘      └───────┬──────┘    └────────┬────────┘  │
│        │                     │                     │           │
│        └─────────────────────┴─────────────────────┘           │
│                              │                                  │
│                    ┌─────────▼──────────┐                       │
│                    │  Medicine Database  │                       │
│                    │  (CSV + Pandas)     │                       │
│                    └────────────────────┘                       │
│                                                                 │
└─────────────────────────────────────────────────────────────────┘
```

## Data Flow

1. User fills the form on `index.html`
2. POST → `/check_medication` in `app.py`
3. Safety Checker runs 3 checks (allergy, interaction, contraindication)
4. Dosage Calculator personalizes the dose
5. Explanation Builder generates human-readable AI reasoning
6. Result is rendered in `result.html`
7. User can generate a Prescription, query the Chatbot, or export PDF
