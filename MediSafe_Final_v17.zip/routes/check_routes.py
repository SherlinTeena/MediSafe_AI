"""
MediSafe AI — Medicine Check Routes
======================================
Handles POST /check_medication and search routes.
"""

from flask import Blueprint, render_template, request, redirect, url_for

check_bp = Blueprint('check', __name__)


@check_bp.route('/check_medication', methods=['POST'])
def check_medication():
    """Process medication safety check form."""
    from app import check_medication as _check
    return _check()


@check_bp.route('/search_medicine', methods=['POST'])
def search_medicine():
    """Search for medicine by name."""
    from app import search_medicine as _search
    return _search()
