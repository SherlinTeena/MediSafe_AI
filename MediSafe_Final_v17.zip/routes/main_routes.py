"""
MediSafe AI — Main Routes
===========================
Home, About, Dashboard, and error page routes.
"""

from flask import Blueprint, render_template, request, jsonify
import datetime

main_bp = Blueprint('main', __name__)


@main_bp.route('/')
def index():
    """Home / check page."""
    from app import MEDICINE_DATABASE
    medicines = sorted(MEDICINE_DATABASE.keys())
    return render_template('index.html', medicines=medicines)


@main_bp.route('/about')
def about():
    """About page."""
    return render_template('about.html')


@main_bp.route('/dashboard')
def dashboard():
    """Analytics dashboard page."""
    from app import MEDICINE_DATABASE
    categories = {}
    for med in MEDICINE_DATABASE.values():
        cat = med.get('category', 'Unknown')
        categories[cat] = categories.get(cat, 0) + 1

    stats = {
        "total_medicines": len(MEDICINE_DATABASE),
        "total_categories": len(categories),
        "categories": categories,
    }
    return render_template('pages/dashboard.html', stats=stats)


@main_bp.route('/api/medicines')
def api_medicines():
    """API: Return all medicine names as JSON."""
    from app import MEDICINE_DATABASE
    return jsonify(sorted(MEDICINE_DATABASE.keys()))


@main_bp.route('/api/medicine/<name>')
def api_medicine_detail(name):
    """API: Return details of a specific medicine."""
    from app import MEDICINE_DATABASE
    med = MEDICINE_DATABASE.get(name.lower())
    if not med:
        return jsonify({"error": "Medicine not found"}), 404
    return jsonify(med)


@main_bp.route('/api/stats')
def api_stats():
    """API: Return database stats."""
    from app import MEDICINE_DATABASE
    categories = {}
    for med in MEDICINE_DATABASE.values():
        cat = med.get('category', 'Other')
        categories[cat] = categories.get(cat, 0) + 1

    return jsonify({
        "total_medicines": len(MEDICINE_DATABASE),
        "categories":      categories,
        "generated_at":    datetime.datetime.now().isoformat(),
    })
