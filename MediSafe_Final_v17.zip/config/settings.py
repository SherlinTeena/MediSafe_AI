"""
MediSafe AI — Application Configuration
========================================
Central config file for all environment settings.
"""

import os

class Config:
    """Base configuration"""
    APP_NAME        = "MediSafe AI"
    VERSION         = "2.0.0"
    AUTHOR          = "Sherlin"
    SECRET_KEY      = os.environ.get('SECRET_KEY', 'medisafe-secret-key-2024')
    DEBUG           = False
    TESTING         = False

    # Database
    MEDICINES_CSV   = os.path.join(os.path.dirname(__file__), '..', 'data', 'medicines.csv')
    MEDICINE_JSON   = os.path.join(os.path.dirname(__file__), '..', 'data', 'medicine_data.json')

    # Upload settings
    MAX_CONTENT_LENGTH  = 16 * 1024 * 1024   # 16 MB
    UPLOAD_FOLDER       = os.path.join(os.path.dirname(__file__), '..', 'uploads')
    ALLOWED_EXTENSIONS  = {'pdf', 'png', 'jpg', 'jpeg', 'txt', 'docx'}

    # Dosage age groups
    CHILD_MAX_AGE   = 11
    ELDERLY_MIN_AGE = 65

    # Safety score weights
    SAFETY_SCORE_BASE          = 100
    ALLERGY_PENALTY            = 40
    INTERACTION_PENALTY        = 20
    CONDITION_WARNING_PENALTY  = 15

    # Chatbot history limit
    CHAT_HISTORY_LIMIT = 10

    # Export
    EXPORT_FOLDER = os.path.join(os.path.dirname(__file__), '..', 'exports')
    LOG_FOLDER    = os.path.join(os.path.dirname(__file__), '..', 'logs')


class DevelopmentConfig(Config):
    DEBUG = True


class ProductionConfig(Config):
    DEBUG = False


class TestingConfig(Config):
    TESTING = True
    DEBUG   = True


# Active config
config = {
    'development': DevelopmentConfig,
    'production':  ProductionConfig,
    'testing':     TestingConfig,
    'default':     DevelopmentConfig
}
