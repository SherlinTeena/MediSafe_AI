"""
MediSafe AI — Helper Utilities
================================
Shared utility functions used across the application.
"""

import os
import re
import json
import hashlib
import datetime
from typing import Any, Dict, List, Optional


def allowed_file(filename: str, allowed_extensions: set) -> bool:
    """Check if uploaded file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in allowed_extensions


def sanitize_text(text: str) -> str:
    """Strip HTML tags and extra whitespace from user input."""
    clean = re.sub(r'<[^>]+>', '', str(text))
    return clean.strip()


def format_medicine_name(name: str) -> str:
    """Capitalize medicine name properly."""
    return name.strip().title()


def pipe_to_comma(text: str) -> str:
    """Convert pipe-separated values to comma-separated."""
    return text.replace('|', ', ') if text else text


def generate_session_id() -> str:
    """Generate a unique session ID."""
    seed = str(datetime.datetime.now()) + os.urandom(8).hex()
    return hashlib.md5(seed.encode()).hexdigest()[:12]


def calculate_bmi(weight_kg: float, height_cm: float) -> Optional[float]:
    """Calculate BMI from weight and height."""
    if height_cm <= 0 or weight_kg <= 0:
        return None
    height_m = height_cm / 100
    return round(weight_kg / (height_m ** 2), 1)


def age_to_group(age: int) -> str:
    """Map numeric age to age group label."""
    if age < 2:    return "infant"
    if age < 12:   return "child"
    if age < 18:   return "adolescent"
    if age < 65:   return "adult"
    return "elderly"


def pretty_date(dt: Optional[datetime.datetime] = None) -> str:
    """Return formatted date string."""
    d = dt or datetime.datetime.now()
    return d.strftime("%A, %d %B %Y")


def safe_float(value: Any, default: float = 0.0) -> float:
    """Safely convert any value to float."""
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def safe_int(value: Any, default: int = 0) -> int:
    """Safely convert any value to int."""
    try:
        return int(value)
    except (TypeError, ValueError):
        return default


def json_response(data: dict, status: int = 200) -> dict:
    """Standard JSON response wrapper."""
    return {"status": "success" if status < 400 else "error", "code": status, "data": data}


def log_event(level: str, message: str, log_dir: str = "logs") -> None:
    """Write a log entry to a daily log file."""
    os.makedirs(log_dir, exist_ok=True)
    fname  = os.path.join(log_dir, f"medisafe_{datetime.date.today()}.log")
    ts     = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry  = f"[{ts}] [{level.upper()}] {message}\n"
    with open(fname, 'a') as f:
        f.write(entry)


def validate_patient_input(data: dict) -> List[str]:
    """
    Validate patient form data.
    Returns list of error messages (empty = valid).
    """
    errors = []
    if not data.get('name', '').strip():
        errors.append("Patient name is required.")

    age = safe_int(data.get('age', 0))
    if age < 1 or age > 120:
        errors.append("Age must be between 1 and 120.")

    weight = safe_float(data.get('weight', 0))
    if weight < 1 or weight > 500:
        errors.append("Weight must be between 1 and 500 kg.")

    if not data.get('disease', '').strip():
        errors.append("Disease/condition is required.")

    if not data.get('medicine', '').strip():
        errors.append("Please select a medicine.")

    return errors
