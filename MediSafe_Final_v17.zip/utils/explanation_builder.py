"""
MediSafe AI — Explanation Builder
====================================
Generates human-readable, HTML-formatted explanations
for why a medicine was recommended (explainable AI output).
"""

from .helpers import pipe_to_comma


def build_explanation(medicine: dict, age: int, weight: float, disease: str, dosage: float) -> str:
    """
    Generate a structured, HTML-formatted AI explanation.
    This is the core 'explainability' output of the system.
    """
    name     = medicine.get('name', 'this medicine')
    category = medicine.get('category', '')
    use      = pipe_to_comma(medicine.get('use', ''))
    se       = medicine.get('side_effects', '')
    food_tk  = medicine.get('food_take', '')

    # Age explanation
    if age < 12:
        age_text = f"A reduced <strong>pediatric dose of {dosage} mg</strong> has been calculated to ensure child safety and appropriate therapeutic levels."
        age_icon = "👶"
    elif age > 65:
        age_text = f"A <strong>reduced elderly dose of {dosage} mg</strong> has been calculated to minimize risk of side effects common in older patients."
        age_icon = "👴"
    else:
        age_text = f"A <strong>standard adult dose of {dosage} mg</strong> has been prescribed, appropriate for your age group."
        age_icon = "🧑"

    # Weight note
    weight_note = ""
    if weight < 50 and age >= 12:
        weight_note = f"<p>⚖️ <strong>Weight Adjustment:</strong> Your weight ({weight} kg) is below 50 kg — the dose has been proportionally reduced for safety.</p>"

    explanation = f"""
<p>🧠 <strong>Why {name} is Recommended for You:</strong></p>
<p>✅ <strong>Primary Match:</strong> You have reported <em>{disease}</em>. {name} belongs to the <strong>{category}</strong> class of medicines and is clinically indicated for: <em>{use}</em>.</p>
<p>{age_icon} <strong>Age-Based Dosage:</strong> {age_text}</p>
{weight_note}
<p>🍽️ <strong>Administration:</strong> {food_tk}</p>
<p>🛡️ <strong>Safety Profile:</strong> {name} is a well-studied medication with a known side-effect profile: <em>{se}</em>. These are typically mild and manageable when taken as directed.</p>
<p>⚕️ <strong>AI Confidence:</strong> This recommendation is based on rule-based matching of your disease profile, age, and weight against our clinical database. Always confirm with a licensed physician.</p>
""".strip()

    return explanation
