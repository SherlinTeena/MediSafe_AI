"""
MediSafe AI — Unit Tests
==========================
Tests for safety checker, chatbot, and prescription service.
Run with: python -m pytest tests/ -v
"""

import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import unittest


class TestSafetyChecker(unittest.TestCase):
    """Tests for the SafetyChecker service."""

    def setUp(self):
        from services.safety_checker import SafetyChecker
        self.checker = SafetyChecker()
        self.sample_med = {
            'name':              'Paracetamol',
            'category':          'Painkillers',
            'use':               'Fever|Pain',
            'adult_dose':        500.0,
            'child_dose':        250.0,
            'elderly_dose':      250.0,
            'max_daily':         2000.0,
            'side_effects':      'Nausea, Liver damage in overdose',
            'interactions':      'warfarin, alcohol',
            'contraindications': 'liver disease, kidney failure',
            'food_avoid':        'Alcohol',
            'food_take':         'With or without food',
            'allergy_warning':   'Penicillin allergy patients: safe to use',
        }

    def test_no_allergy_returns_empty(self):
        result = self.checker.check_allergies(self.sample_med, [])
        self.assertEqual(result, [])

    def test_allergy_detected(self):
        result = self.checker.check_allergies(self.sample_med, ['paracetamol'])
        self.assertTrue(len(result) > 0)
        self.assertEqual(result[0]['severity'], 'CRITICAL')

    def test_drug_interaction_detected(self):
        result = self.checker.check_interactions(self.sample_med, ['warfarin'])
        self.assertTrue(len(result) > 0)

    def test_no_interaction_when_clear(self):
        result = self.checker.check_interactions(self.sample_med, ['vitamin c'])
        self.assertEqual(result, [])

    def test_adult_dosage_calculation(self):
        dose, cat = self.checker.calculate_dosage(self.sample_med, 30, 70)
        self.assertEqual(dose, 500.0)
        self.assertEqual(cat, 'adult')

    def test_child_dosage_calculation(self):
        dose, cat = self.checker.calculate_dosage(self.sample_med, 8, 25)
        self.assertEqual(dose, 250.0)
        self.assertEqual(cat, 'child')

    def test_elderly_dosage_calculation(self):
        dose, cat = self.checker.calculate_dosage(self.sample_med, 70, 60)
        self.assertEqual(dose, 250.0)
        self.assertEqual(cat, 'elderly')

    def test_safety_score_full(self):
        score = self.checker.calculate_safety_score([], [], [])
        self.assertEqual(score, 100)

    def test_safety_score_with_critical(self):
        warnings = [{'severity': 'CRITICAL', 'message': 'Test'}]
        score = self.checker.calculate_safety_score(warnings, [], [])
        self.assertLess(score, 100)


class TestChatbotService(unittest.TestCase):
    """Tests for the ChatbotService."""

    def setUp(self):
        from services.chatbot_service import ChatbotService
        self.bot = ChatbotService()

    def test_greeting_intent(self):
        self.assertEqual(self.bot.detect_intent('hi there'), 'greeting')
        self.assertEqual(self.bot.detect_intent('hello'), 'greeting')

    def test_food_intent(self):
        self.assertEqual(self.bot.detect_intent('what food should I avoid'), 'food')

    def test_dosage_intent(self):
        self.assertEqual(self.bot.detect_intent('what is the dose?'), 'dosage')

    def test_bye_intent(self):
        self.assertEqual(self.bot.detect_intent('bye goodbye'), 'bye')

    def test_unknown_intent(self):
        self.assertEqual(self.bot.detect_intent('xyzzy random nonsense 12345'), 'unknown')


class TestHelpers(unittest.TestCase):
    """Tests for utility helper functions."""

    def setUp(self):
        from utils.helpers import (
            sanitize_text, pipe_to_comma, safe_float,
            safe_int, age_to_group, validate_patient_input
        )
        self.sanitize    = sanitize_text
        self.pipe        = pipe_to_comma
        self.safe_float  = safe_float
        self.safe_int    = safe_int
        self.age_to_group= age_to_group
        self.validate    = validate_patient_input

    def test_sanitize_removes_html(self):
        result = self.sanitize('<b>Hello</b> World')
        self.assertEqual(result, 'Hello World')

    def test_pipe_to_comma(self):
        result = self.pipe('Fever|Pain|Infection')
        self.assertEqual(result, 'Fever, Pain, Infection')

    def test_safe_float_valid(self):
        self.assertEqual(self.safe_float('3.14'), 3.14)

    def test_safe_float_invalid(self):
        self.assertEqual(self.safe_float('abc'), 0.0)

    def test_safe_int_valid(self):
        self.assertEqual(self.safe_int('42'), 42)

    def test_age_groups(self):
        self.assertEqual(self.age_to_group(5),  'child')
        self.assertEqual(self.age_to_group(30), 'adult')
        self.assertEqual(self.age_to_group(70), 'elderly')

    def test_validate_valid_input(self):
        data = {'name':'Test', 'age':25, 'weight':65, 'disease':'Fever', 'medicine':'paracetamol'}
        errors = self.validate(data)
        self.assertEqual(errors, [])

    def test_validate_missing_name(self):
        data = {'name':'', 'age':25, 'weight':65, 'disease':'Fever', 'medicine':'paracetamol'}
        errors = self.validate(data)
        self.assertTrue(len(errors) > 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
