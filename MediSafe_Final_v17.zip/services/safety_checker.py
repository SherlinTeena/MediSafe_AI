"""
MediSafe AI — Safety Checker Service
======================================
Core explainable AI logic for medication safety analysis.
Checks: allergies, drug interactions, contraindications, dosage.
"""

from typing import List, Tuple, Dict, Optional


class SafetyChecker:
    """
    Rule-based explainable AI engine for medication safety.
    Each check returns a list of warning dicts: {severity, message}
    """

    SEVERITY_CRITICAL = "CRITICAL"
    SEVERITY_HIGH     = "HIGH"
    SEVERITY_MODERATE = "MODERATE"
    SEVERITY_LOW      = "LOW"

    # Known high-risk interaction pairs
    HIGH_RISK_PAIRS = {
        ('warfarin', 'aspirin'):       "Severe bleeding risk",
        ('metformin', 'alcohol'):      "Lactic acidosis risk",
        ('ssri', 'maoi'):              "Serotonin syndrome risk",
        ('digoxin', 'amiodarone'):     "Cardiac toxicity risk",
    }

    def check_allergies(self, medicine: dict, allergies_list: List[str]) -> List[dict]:
        """Check if patient is allergic to the medicine or its class."""
        warnings = []
        med_name      = medicine.get('name', '').lower()
        allergy_warn  = medicine.get('allergy_warning', '').lower()
        category      = medicine.get('category', '').lower()

        for allergy in allergies_list:
            a = allergy.lower().strip()
            if a and (a in med_name or a in allergy_warn or a in category):
                warnings.append({
                    "severity": self.SEVERITY_CRITICAL,
                    "message":  f"Patient has a documented allergy to '{allergy}' — this medicine may be contraindicated."
                })
        return warnings

    def check_interactions(self, medicine: dict, current_meds: List[str]) -> List[dict]:
        """Check for drug-drug interactions."""
        warnings = []
        interaction_str = medicine.get('interactions', '').lower()

        for med in current_meds:
            m = med.lower().strip()
            if m and m in interaction_str:
                warnings.append({
                    "severity": self.SEVERITY_HIGH,
                    "message":  f"Potential interaction with '{med}' — consult your doctor before combining."
                })
        return warnings

    def check_contraindications(self, medicine: dict, conditions_list: List[str]) -> List[dict]:
        """Check medicine contraindications against patient's conditions."""
        warnings = []
        contra_str = medicine.get('contraindications', '').lower()

        for condition in conditions_list:
            c = condition.lower().strip()
            if c and c in contra_str:
                warnings.append({
                    "severity": self.SEVERITY_MODERATE,
                    "message":  f"This medicine may be contraindicated with '{condition}' — medical supervision required."
                })
        return warnings

    def calculate_dosage(self, medicine: dict, age: int, weight: float) -> Tuple[float, str]:
        """
        Calculate personalized dosage based on age and weight.
        Returns (dosage_mg, age_category_label).
        """
        if age < 12:
            dose     = float(medicine.get('child_dose', 0))
            category = "child"
        elif age > 65:
            dose     = float(medicine.get('elderly_dose', 0))
            category = "elderly"
        else:
            dose     = float(medicine.get('adult_dose', 0))
            category = "adult"

        # Weight-based adjustment for underweight adults
        if weight < 50 and age >= 12 and dose > 0:
            dose = round(dose * (weight / 70), 1)

        return dose, category

    def calculate_safety_score(self,
                                allergy_warnings: List[dict],
                                interaction_warnings: List[dict],
                                condition_warnings: List[dict]) -> int:
        """
        Calculate overall safety score 0–100.
        Starts at 100, deducts points per warning severity.
        """
        score = 100
        penalties = {
            self.SEVERITY_CRITICAL: 50,
            self.SEVERITY_HIGH:     25,
            self.SEVERITY_MODERATE: 15,
            self.SEVERITY_LOW:      5,
        }

        for w in allergy_warnings + interaction_warnings + condition_warnings:
            score -= penalties.get(w.get('severity', ''), 10)

        return max(0, min(100, score))

    def determine_status(self, allergy_warnings: List[dict],
                         interaction_warnings: List[dict],
                         condition_warnings: List[dict],
                         dosage: float) -> Tuple[str, str, bool]:
        """
        Returns (status_text, css_class, is_safe).
        """
        if allergy_warnings:
            return "⛔ NOT RECOMMENDED — Allergy Risk", "danger", False

        if dosage == 0:
            return "⛔ NOT RECOMMENDED — Age/Weight Issue", "danger", False

        if interaction_warnings or condition_warnings:
            return "⚠️ USE WITH CAUTION — Warnings Found", "warning", True

        return "✅ SAFE TO USE", "safe", True

    def full_check(self, medicine: dict, patient: dict) -> dict:
        """Run all safety checks and return a comprehensive result dict."""
        age           = int(patient.get('age', 25))
        weight        = float(patient.get('weight', 60))
        allergies     = [a.strip().lower() for a in str(patient.get('allergies', '')).split(',') if a.strip()]
        current_meds  = [m.strip().lower() for m in str(patient.get('current_meds', '')).split(',') if m.strip()]
        conditions    = [c.strip().lower() for c in str(patient.get('conditions', '')).split(',') if c.strip()]

        allergy_w     = self.check_allergies(medicine, allergies)
        interaction_w = self.check_interactions(medicine, current_meds)
        condition_w   = self.check_contraindications(medicine, conditions)
        dosage, age_cat = self.calculate_dosage(medicine, age, weight)
        score         = self.calculate_safety_score(allergy_w, interaction_w, condition_w)
        status, css, safe = self.determine_status(allergy_w, interaction_w, condition_w, dosage)

        return {
            "is_safe":              safe,
            "status":               status,
            "status_class":         css,
            "safety_score":         score,
            "dosage":               dosage,
            "age_category":         age_cat,
            "allergy_warnings":     allergy_w,
            "interaction_warnings": interaction_w,
            "condition_warnings":   condition_w,
        }


# Singleton
safety_checker = SafetyChecker()
