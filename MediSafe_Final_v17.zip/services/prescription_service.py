"""
MediSafe AI — Prescription Service
=====================================
Generates doctor-style prescriptions with
timing, food instructions, and special notes.
"""

from typing import List, Dict


class PrescriptionService:
    """Generates structured prescription data from patient + medicine info."""

    SCHEDULES = {
        1: [{"time": "Morning",   "icon": "🌅", "clock": "8:00 AM"}],
        2: [{"time": "Morning",   "icon": "🌅", "clock": "8:00 AM"},
            {"time": "Night",     "icon": "🌙", "clock": "8:00 PM"}],
        3: [{"time": "Morning",   "icon": "🌅", "clock": "8:00 AM"},
            {"time": "Afternoon", "icon": "☀️",  "clock": "2:00 PM"},
            {"time": "Night",     "icon": "🌙", "clock": "8:00 PM"}],
    }

    DURATION_MAP = {
        'fever':       ("3–5 days",          "Stop if symptoms resolve. See doctor if no improvement."),
        'pain':        ("3–5 days",          "Do not exceed recommended dose for pain relief."),
        'headache':    ("3–5 days",          "If headaches persist, consult a neurologist."),
        'cold':        ("5–7 days",          "Rest and stay hydrated alongside medication."),
        'infection':   ("7–10 days",         "Complete full course even if symptoms improve."),
        'antibiotic':  ("7–10 days",         "Never stop antibiotics early — risk of resistance."),
        'bacteria':    ("7–10 days",         "Complete full antibiotic course."),
        'throat':      ("5–7 days",          "Gargle with warm salt water alongside medication."),
        'diabetes':    ("Ongoing",           "Do not stop without consulting your endocrinologist."),
        'blood pressure': ("Ongoing",        "Take at same time daily. Monitor BP regularly."),
        'cholesterol': ("Ongoing",           "Combine with diet changes and exercise."),
        'heart':       ("Ongoing",           "Never miss a dose. Always carry your medication."),
        'allergy':     ("7–14 days",         "Continue until symptoms fully resolve."),
        'rash':        ("7–14 days",         "Avoid scratching — keep the area clean and dry."),
        'chest':       ("7–10 days",         "If breathing difficulty worsens, visit ER immediately."),
    }

    def determine_food_timing(self, food_take: str) -> tuple:
        """Returns (full_label, short_label) for food timing."""
        ftl = food_take.lower()
        if 'empty stomach' in ftl or 'before' in ftl:
            return "Before meal (30 min prior)", "Before meal"
        elif 'after' in ftl or 'with food' in ftl or 'with meal' in ftl:
            return "After meal or with food", "After meal"
        return "With or after food", "With food"

    def determine_duration(self, problem: str) -> tuple:
        """Returns (duration_str, note_str) based on problem keywords."""
        pl = problem.lower()
        for keyword, (dur, note) in self.DURATION_MAP.items():
            if keyword in pl:
                return dur, note
        return "5–7 days", "Follow your doctor's specific advice on duration."

    def special_instructions(self, medicine: dict, food_take: str) -> List[str]:
        """Generate special instructions list from medicine data."""
        instructions = []
        fa  = medicine.get('food_avoid', '').lower()
        ftl = food_take.lower()

        if 'alcohol'   in fa: instructions.append("🚫 Avoid alcohol completely during course")
        if 'dairy'     in fa or 'milk' in fa: instructions.append("🥛 Avoid dairy 2 hrs before/after dose")
        if 'grapefruit'in fa: instructions.append("🍊 Avoid grapefruit and grapefruit juice")
        if 'empty stomach' in ftl: instructions.append("🍽️ Take on empty stomach — 30 min before eating")

        instructions.append("💧 Drink a full glass of water with each dose")
        instructions.append("⏰ Take at the same time every day for best results")
        instructions.append("🗓️ Do not stop medication abruptly without doctor's advice")
        return instructions

    def generate(self, medicine: dict, problem: str,
                 age: int = 25, weight: float = 60,
                 patient_name: str = "Patient") -> Dict:
        """Full prescription generator. Returns structured prescription dict."""

        if age < 12:   dose = float(medicine.get('child_dose', 0)); age_group = "Child"
        elif age > 65: dose = float(medicine.get('elderly_dose', 0)); age_group = "Elderly"
        else:          dose = float(medicine.get('adult_dose', 0));  age_group = "Adult"

        if weight < 50 and age >= 12 and dose > 0:
            dose = round(dose * (weight / 70), 1)

        max_d = float(medicine.get('max_daily', 0))
        times = min(3, int(max_d / dose)) if dose > 0 else 1
        times = max(1, times)

        food_timing, food_short = self.determine_food_timing(medicine.get('food_take', ''))
        duration, dur_note = self.determine_duration(problem)

        schedule = []
        for slot in self.SCHEDULES.get(times, self.SCHEDULES[1]):
            schedule.append({**slot, "dose": dose, "note": food_short})

        return {
            "medicine":             medicine.get('name', ''),
            "category":             medicine.get('category', ''),
            "problem":              problem,
            "patient_name":         patient_name,
            "age_group":            age_group,
            "dose":                 dose,
            "times_per_day":        times,
            "max_daily":            max_d,
            "food_timing":          food_timing,
            "food_avoid":           medicine.get('food_avoid', ''),
            "schedule":             schedule,
            "duration":             duration,
            "duration_note":        dur_note,
            "special_instructions": self.special_instructions(medicine, medicine.get('food_take', '')),
            "side_effects":         medicine.get('side_effects', ''),
        }


# Singleton
prescription_service = PrescriptionService()
