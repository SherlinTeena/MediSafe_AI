"""
MediSafe AI — Chatbot Service
===============================
Rule-based NLP chatbot with intent detection and
personalized response generation for medication queries.
"""

from typing import List, Tuple, Optional


class ChatbotService:
    """
    Intent-based chatbot engine for medicine queries.
    Supports 12 intents with personalized, medically-informed responses.
    """

    INTENTS = {
        'greeting':    ['hi', 'hello', 'hey', 'good morning', 'good evening', 'howdy', 'namaste'],
        'thankyou':    ['thank you', 'thanks', 'thank u', 'thankyou', 'ty', 'thx', 'appreciate', 'grateful'],
        'bye':         ['bye', 'goodbye', 'see you', 'see ya', 'take care', 'later', 'good night', 'ciao'],
        'food':        ['food', 'eat', 'drink', 'meal', 'diet', 'stomach', 'empty', 'avoid'],
        'dosage':      ['dose', 'dosage', 'how much', 'quantity', 'mg', 'amount', 'how many', 'intake'],
        'side_effects':['side effect', 'side-effect', 'adverse', 'reaction', 'harm', 'danger', 'risk', 'problem'],
        'interaction': ['interaction', 'combine', 'mix', 'together', 'other medicine', 'drug', 'concurrent'],
        'allergy':     ['allergy', 'allergic', 'rash', 'hives', 'anaphylaxis', 'intolerance'],
        'usage':       ['what is', 'used for', 'purpose', 'treat', 'category', 'type', 'works', 'use'],
        'safe':        ['safe', 'safety', 'danger', 'is it ok', 'can i take', 'should i', 'recommended'],
        'summary':     ['summary', 'overview', 'all info', 'everything', 'complete', 'full detail'],
        'storage':     ['store', 'storage', 'keep', 'refrigerate', 'temperature', 'shelf', 'expire'],
    }

    def detect_intent(self, text: str) -> str:
        """Detect user intent from message text."""
        text_lower = text.lower().strip()
        for intent, keywords in self.INTENTS.items():
            if any(kw in text_lower for kw in keywords):
                return intent
        return 'unknown'

    def generate_response(self, intent: str, medicine: dict,
                          patient_name: str = "Patient",
                          chat_history: Optional[List[dict]] = None) -> str:
        """Generate a contextual, personalized response for the given intent."""

        med_name = medicine.get('name', 'this medicine')
        category = medicine.get('category', '')
        use      = medicine.get('use', '').replace('|', ', ')
        se       = medicine.get('side_effects', '')
        food_av  = medicine.get('food_avoid', '')
        food_tk  = medicine.get('food_take', '')
        inter    = medicine.get('interactions', '')
        allergy_w= medicine.get('allergy_warning', '')
        ad       = medicine.get('adult_dose', '?')
        cd       = medicine.get('child_dose', '?')
        ed       = medicine.get('elderly_dose', '?')
        max_d    = medicine.get('max_daily', '?')

        R = {
            'greeting': (
                f"👋 Hello, <strong>{patient_name}</strong>! I'm your MediSafe AI assistant.<br><br>"
                f"I'm here to help you understand everything about <strong>{med_name}</strong>. "
                f"Ask me about dosage, side effects, food interactions, safety, and more! 😊"
            ),
            'thankyou': (
                f"😊 You're very welcome, <strong>{patient_name}</strong>!<br>"
                f"Stay healthy and always take <strong>{med_name}</strong> as prescribed. 💊<br>"
                f"Feel free to ask if you have more questions!"
            ),
            'bye': (
                f"👋 Goodbye, <strong>{patient_name}</strong>! Take care and stay safe.<br>"
                f"Remember to complete your course of <strong>{med_name}</strong> as advised. 🌟"
            ),
            'food': (
                f"🍽️ <strong>Food Guidelines for {med_name}:</strong><br><br>"
                f"🚫 <strong>Avoid:</strong> {food_av}<br><br>"
                f"✅ <strong>How to take:</strong> {food_tk}<br><br>"
                f"<em>Why?</em> Certain foods can affect how your body absorbs and processes {med_name}, "
                f"altering its effectiveness or causing unwanted side effects."
            ),
            'dosage': (
                f"💊 <strong>Dosage for {med_name}:</strong><br><br>"
                f"👶 <strong>Child (under 12):</strong> {cd} mg<br>"
                f"🧑 <strong>Adult (12–65):</strong> {ad} mg<br>"
                f"👴 <strong>Elderly (65+):</strong> {ed} mg<br>"
                f"📊 <strong>Maximum daily dose:</strong> {max_d} mg<br><br>"
                f"<em>Why this dose?</em> These doses are calibrated based on clinical trials for each "
                f"age group to balance therapeutic benefit against side-effect risk."
            ),
            'side_effects': (
                f"⚠️ <strong>Possible Side Effects of {med_name}:</strong><br><br>"
                f"{se}<br><br>"
                f"Most side effects are mild and temporary. Contact your doctor immediately if you "
                f"experience severe allergic reactions, difficulty breathing, or chest pain."
            ),
            'interaction': (
                f"🔄 <strong>Drug Interactions for {med_name}:</strong><br><br>"
                f"Known interactions with: <strong>{inter if inter else 'None documented'}</strong><br><br>"
                f"Always inform your doctor about ALL medications you are currently taking, "
                f"including over-the-counter drugs and herbal supplements."
            ),
            'allergy': (
                f"🌡️ <strong>Allergy Information for {med_name}:</strong><br><br>"
                f"{allergy_w if allergy_w else 'No specific allergy warnings on record.'}<br><br>"
                f"Category: <strong>{category}</strong><br>"
                f"If you have had any previous reactions to medicines in this category, "
                f"please consult your doctor before taking {med_name}."
            ),
            'usage': (
                f"📋 <strong>What is {med_name} used for?</strong><br><br>"
                f"<strong>Category:</strong> {category}<br>"
                f"<strong>Treats:</strong> {use}<br><br>"
                f"{med_name} works by targeting specific biological pathways related to these conditions. "
                f"Always use it only for the condition your doctor has prescribed it for."
            ),
            'safe': (
                f"🛡️ <strong>Safety Profile of {med_name}:</strong><br><br>"
                f"✅ Clinically approved for: {use}<br>"
                f"⚠️ Side effects to watch: {se}<br>"
                f"🚫 Avoid with: {food_av}<br><br>"
                f"This is a generally well-tolerated medication when taken as directed. "
                f"Your MediSafe analysis has already checked your personal safety profile."
            ),
            'summary': (
                f"📋 <strong>Complete Summary — {med_name}:</strong><br><br>"
                f"<strong>Category:</strong> {category}<br>"
                f"<strong>Treats:</strong> {use}<br>"
                f"<strong>Adult Dose:</strong> {ad} mg | <strong>Max Daily:</strong> {max_d} mg<br>"
                f"<strong>Side Effects:</strong> {se}<br>"
                f"<strong>Avoid:</strong> {food_av}<br>"
                f"<strong>How to Take:</strong> {food_tk}<br>"
                f"<strong>Interactions:</strong> {inter if inter else 'None documented'}"
            ),
            'storage': (
                f"📦 <strong>Storage Instructions for {med_name}:</strong><br><br>"
                f"🌡️ Store at room temperature (15–25°C / 59–77°F)<br>"
                f"☀️ Keep away from direct sunlight and heat<br>"
                f"💧 Store in a dry place — avoid humid areas like bathrooms<br>"
                f"🔒 Keep out of reach of children<br>"
                f"🗓️ Check expiry date before each use and discard expired medicine."
            ),
            'unknown': (
                f"🤔 I'm not sure I understood that, <strong>{patient_name}</strong>!<br><br>"
                f"I can help you with: <strong>dosage, food, side effects, interactions, "
                f"allergy, safety, usage, storage,</strong> or a <strong>full summary</strong> of "
                f"<strong>{med_name}</strong>.<br>Try asking one of these topics!"
            ),
        }

        return R.get(intent, R['unknown'])


# Singleton
chatbot_service = ChatbotService()
