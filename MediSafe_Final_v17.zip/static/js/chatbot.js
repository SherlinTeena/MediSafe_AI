/* MediSafe AI Chatbot Module - full version is inlined in result.html */
console.log("MediSafe AI Chatbot loaded");
