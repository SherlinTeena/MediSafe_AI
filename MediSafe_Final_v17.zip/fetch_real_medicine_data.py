"""
MediSafe AI — Real Medicine Data Fetcher
Run this ONCE inside your MediSafe project folder:
    pip install requests
    python fetch_real_medicine_data.py
"""
import requests, csv, re, time, os

CSV_PATH    = 'medicines.csv'
BACKUP_PATH = 'medicines_backup_original.csv'
FDA_BASE    = 'https://api.fda.gov/drug/label.json'
DELAY       = 0.5

NAME_MAP = {
    'paracetamol':'acetaminophen','vitamin d3':'cholecalciferol',
    'vitamin b12':'cyanocobalamin','vitamin c':'ascorbic acid',
    'iron supplement':'ferrous sulfate','salbutamol':'albuterol',
    'glibenclamide':'glyburide','mefenamic acid':'mefenamic acid',
    'calcium carbonate':'calcium carbonate','folic acid':'folic acid',
}

def remove_boilerplate(text):
    if not text: return ''
    text = re.sub(r'\b\d+(\.\d+)?\s+[A-Z][A-Z\s]{3,}\b', ' ', text)
    text = re.sub(r'\[see [^\]]+\]', '', text)
    text = re.sub(r'\(see [^)]+\)', '', text)
    text = re.sub(r'prescribing information[\s\w]*\.?', '', text, flags=re.IGNORECASE)
    text = re.sub(r'the following[\w\s,]+are also discussed elsewhere[^.]+\.', '', text, flags=re.IGNORECASE)
    text = re.sub(r'\(\d+\.?\d*%\)', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

def good_sentences(text, n=3):
    text = remove_boilerplate(text)
    sentences = re.split(r'(?<=[.!?])\s+', text)
    good = [s.strip() for s in sentences if len(s.strip()) > 20 and not s.strip().isupper()]
    return ' '.join(good[:n])

def simplify_side_effects(raw):
    if not raw: return ''
    text = remove_boilerplate(raw)
    pattern = re.compile(
        r'\b(nausea|vomiting|diarrhea|diarrhoea|headache|dizziness|drowsiness|fatigue|'
        r'weakness|rash|itching|stomach pain|stomach upset|abdominal pain|constipation|'
        r'dry mouth|blurred vision|muscle pain|muscle cramps|joint pain|back pain|cough|'
        r'shortness of breath|chest pain|palpitation|insomnia|anxiety|confusion|tremor|'
        r'low blood sugar|hypoglycemia|low blood pressure|hypotension|weight gain|weight loss|'
        r'increased urination|increased thirst|lactic acidosis|liver damage|liver toxicity|'
        r'kidney damage|anemia|bleeding|bruising|swelling|flushing|hair loss|'
        r'loss of appetite|metallic taste|taste changes)\b', re.IGNORECASE)
    found, seen = [], set()
    for m in pattern.finditer(text):
        e = m.group().strip().lower()
        if e not in seen:
            seen.add(e)
            serious = any(s in e for s in ['lactic acidosis','liver damage','kidney damage','bleeding'])
            label = e[0].upper()+e[1:]
            found.append(label + ' (serious — see doctor immediately)' if serious else label)
    return ', '.join(found[:8]) if found else good_sentences(text, 2)

def simplify_use(raw_purpose, raw_indications):
    raw = raw_purpose or raw_indications
    if not raw: return ''
    text = remove_boilerplate(raw)
    text = re.sub(r'\b[A-Z]{4,}\b', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return good_sentences(text, 2)

def simplify_contraindications(raw):
    if not raw: return ''
    text = remove_boilerplate(raw)
    pattern = re.compile(
        r'\b(kidney disease|kidney failure|liver disease|liver failure|heart disease|heart failure|'
        r'pregnancy|breastfeeding|allergy to \w+|epilepsy|seizures?|asthma|COPD|'
        r'children under \d+|hypersensitivity|G6PD deficiency|bleeding disorder|'
        r'active bleeding|peptic ulcer|stomach ulcer|renal impairment|hepatic impairment)\b',
        re.IGNORECASE)
    found, seen = [], set()
    for m in pattern.finditer(text):
        c = m.group().strip()
        if c.lower() not in seen:
            seen.add(c.lower())
            found.append(c[0].upper()+c[1:])
    return ' | '.join(found[:6]) if found else good_sentences(text, 2)

def simplify_interactions(raw):
    if not raw: return ''
    pattern = re.compile(
        r'\b(warfarin|aspirin|ibuprofen|metformin|digoxin|lithium|cyclosporine|'
        r'methotrexate|phenytoin|carbamazepine|rifampicin|rifampin|ketoconazole|'
        r'fluconazole|clarithromycin|erythromycin|amiodarone|cimetidine|antacids?|'
        r'alcohol|NSAIDs?|MAO inhibitors?|anticoagulants?|diuretics?|beta.?blockers?|'
        r'calcium channel blockers?|ACE inhibitors?|statins?|insulin|theophylline|'
        r'potassium supplements?|iron supplements?|calcium supplements?)\b', re.IGNORECASE)
    found, seen = [], set()
    for m in pattern.finditer(raw):
        d = m.group().strip()
        if d.lower() not in seen:
            seen.add(d.lower())
            found.append(d[0].upper()+d[1:])
    return ' | '.join(found[:8])

def fetch_fda(name):
    search = NAME_MAP.get(name.lower(), name.lower())
    for q in [f'openfda.generic_name:"{search}"', f'openfda.substance_name:"{search}"']:
        try:
            r = requests.get(FDA_BASE, params={'search':q,'limit':1}, timeout=10)
            if r.status_code == 200:
                data = r.json()
                if data.get('results'):
                    return data['results'][0]
        except: pass
        time.sleep(0.2)
    return None

def apply_fda(row, fda):
    openfda = fda.get('openfda', {})
    generics = openfda.get('generic_name', [])
    brands   = openfda.get('brand_name', [])

    simple_use   = simplify_use(fda.get('purpose',[''])[0], fda.get('indications_and_usage',[''])[0])
    simple_fx    = simplify_side_effects(fda.get('adverse_reactions', fda.get('side_effects',['']))[0])
    simple_inter = simplify_interactions(fda.get('drug_interactions',[''])[0])
    simple_avoid = simplify_contraindications(fda.get('contraindications',[''])[0])
    simple_warn  = good_sentences(fda.get('warnings', fda.get('warnings_and_cautions',['']))[0], 2)

    if simple_use   and len(simple_use)  > 15: row['use']             = simple_use
    if simple_fx    and len(simple_fx)   > 10: row['side_effects']    = simple_fx
    if simple_inter:                            row['interactions']    = simple_inter
    if simple_avoid and len(simple_avoid)> 10: row['conditions_avoid']= simple_avoid

    row['fda_source']   = f"OpenFDA | {generics[0] if generics else 'N/A'} | {brands[0] if brands else 'N/A'}"
    row['fda_warnings'] = simple_warn
    return row

def main():
    print("="*60)
    print("  MediSafe AI — OpenFDA Data Fetcher")
    print("  Fetches REAL FDA data + simplifies for patients")
    print("="*60+"\n")

    if not os.path.exists(CSV_PATH):
        print(f"ERROR: {CSV_PATH} not found. Run from your MediSafe folder.")
        return

    with open(CSV_PATH,'r',encoding='utf-8') as f: backup=f.read()
    with open(BACKUP_PATH,'w',encoding='utf-8') as f: f.write(backup)
    print(f"✅ Backup saved: {BACKUP_PATH}\n")

    with open(CSV_PATH,'r',newline='',encoding='utf-8') as f:
        reader=csv.DictReader(f); rows=list(reader); fieldnames=list(reader.fieldnames)

    for col in ['fda_source','fda_warnings']:
        if col not in fieldnames: fieldnames.append(col)

    print(f"Processing {len(rows)} medicines...\n")
    fetched, not_found = [], []

    for i, row in enumerate(rows):
        name = row['medicine_name'].strip()
        print(f"  [{i+1:3}/{len(rows)}] {name:<28}", end=" ", flush=True)
        fda = fetch_fda(name)
        if fda:
            rows[i] = apply_fda(row, fda)
            fetched.append(name)
            print("✅ Real data applied")
        else:
            not_found.append(name)
            print("⚠️  Not found — original kept")
        time.sleep(DELAY)

    with open(CSV_PATH,'w',newline='',encoding='utf-8') as f:
        writer=csv.DictWriter(f,fieldnames=fieldnames)
        writer.writeheader(); writer.writerows(rows)

    print(f"\n{'='*60}")
    print(f"  ✅ Real FDA data applied : {len(fetched)} medicines")
    print(f"  ⚠️  Original kept        : {len(not_found)} medicines")
    print(f"\n  Restart app: python app.py")
    print(f"{'='*60}")

if __name__=='__main__': main()
