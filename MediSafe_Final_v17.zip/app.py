"""
MediSafe AI — Explainable AI-Based Personalized Medication Safety System
Modified Version: Checkboxes | Dynamic Score | Separate Prescription | Separate Chatbot
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, session
import pandas as pd
import os
import datetime
import json
from datetime import timedelta

app = Flask(__name__)
# Fixed permanent secret key — sessions survive restarts
app.secret_key = 'medisafe_xai_2024_sherlin_karunya_secure_key_v1'
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SESSION_COOKIE_PATH'] = '/'
app.config['SESSION_COOKIE_SECURE'] = False
app.config['SESSION_PERMANENT'] = True
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(days=30)
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_REFRESH_EACH_REQUEST'] = True

@app.before_request
def make_session_permanent():
    session.permanent = True

# ── File-based user storage (persists across restarts) ──────
USERS_FILE = os.path.join(os.path.dirname(__file__), 'users_data.json')

def load_users():
    if os.path.exists(USERS_FILE):
        try:
            with open(USERS_FILE, 'r') as f:
                return json.load(f)
        except:
            pass
    return {}

def save_users(users):
    with open(USERS_FILE, 'w') as f:
        json.dump(users, f, indent=2)

# ─────────────────────────────────────────────────────
# LOAD MEDICINE DATABASE
# ─────────────────────────────────────────────────────

import re as _re

def _clean_medical_text(text, maxlen=250):
    """Clean raw FDA/CSV text for patient-friendly display."""
    if not text or str(text).strip() in ['', 'nan', 'None']:
        return ''
    text = str(text)
    # Remove FDA section numbers like "6 ADVERSE REACTIONS"
    text = _re.sub(r'\b\d+(\.\d+)?\s+[A-Z][A-Z\s]{3,}\b', ' ', text)
    # Remove [see ...] cross references
    text = _re.sub(r'\[see [^\]]+\]', '', text)
    text = _re.sub(r'\(see [^)]+\)', '', text)
    # Remove "prescribing information" phrases
    text = _re.sub(r'prescribing information[\s\w]*\.?', '', text, flags=_re.IGNORECASE)
    text = _re.sub(r'the following[\w\s,]+are also discussed elsewhere[^.]+\.', '', text, flags=_re.IGNORECASE)
    # Remove percentage values
    text = _re.sub(r'\(\d+\.?\d*%\)', '', text)
    # Remove ALL CAPS brand names (4+ letters all caps)
    text = _re.sub(r'\b[A-Z]{4,}\b', '', text)
    # Clean whitespace
    text = _re.sub(r'\s+', ' ', text).strip()
    # Truncate to max length at sentence boundary
    if len(text) > maxlen:
        cut = text[:maxlen]
        last_dot = cut.rfind('.')
        if last_dot > maxlen // 2:
            cut = cut[:last_dot+1]
        text = cut
    return text


def load_medicine_database():
    csv_path = os.path.join(os.path.dirname(__file__), 'medicines.csv')
    try:
        df = pd.read_csv(csv_path)
        medicine_db = {}
        for _, row in df.iterrows():
            key = row['medicine_name'].lower().strip()
            medicine_db[key] = {
                'name':             row['medicine_name'],
                'category':         row['category'],
                'use':              _clean_medical_text(row['use'], 200),
                'adult_dose':       float(row['adult_dose']),
                'child_dose':       float(row['child_dose']),
                'elderly_dose':     float(row['elderly_dose']),
                'max_daily':        float(row['max_daily']),
                'side_effects':     _clean_medical_text(row['side_effects'], 200),
                'food_avoid':       row['food_avoid'],
                'food_take':        row['food_take'],
                'interactions':     [x.strip() for x in str(row['interactions']).split('|')],
                'allergies':        [x.strip() for x in str(row['allergies']).split('|')],
                'conditions_avoid': [x.strip() for x in str(row['conditions_avoid']).split('|')],
            }
        print(f"✅ {len(medicine_db)} medicines loaded")
        return medicine_db
    except Exception as e:
        print(f"❌ Error: {e}")
        return {}

MEDICINE_DATABASE = load_medicine_database()

# ─────────────────────────────────────────────────────
# SAFETY HELPERS
# ─────────────────────────────────────────────────────

# Real tablet sizes available in Indian pharmacies
REAL_TABLET_SIZES = {
    'paracetamol':      [250, 500, 650],
    'ibuprofen':        [200, 400, 600, 800],
    'aspirin':          [75, 150, 325],
    'diclofenac':       [25, 50, 75, 100],
    'tramadol':         [50, 100],
    'mefenamic acid':   [250, 500],
    'naproxen':         [250, 500],
    'amoxicillin':      [250, 500],
    'azithromycin':     [250, 500],
    'ciprofloxacin':    [250, 500, 750],
    'doxycycline':      [50, 100],
    'metronidazole':    [200, 400, 500],
    'cetirizine':       [5, 10],
    'loratadine':       [10],
    'levocetirizine':   [2, 5],
    'fexofenadine':     [60, 120, 180],
    'omeprazole':       [10, 20, 40],
    'pantoprazole':     [20, 40],
    'esomeprazole':     [20, 40],
    'ondansetron':      [4, 8],
    'domperidone':      [10],
    'metformin':        [500, 850, 1000],
    'glibenclamide':    [2, 5],
    'glipizide':        [2, 5, 10],
    'sitagliptin':      [25, 50, 100],
    'amlodipine':       [2, 5, 10],
    'atenolol':         [25, 50, 100],
    'lisinopril':       [2, 5, 10, 20],
    'losartan':         [25, 50, 100],
    'telmisartan':      [20, 40, 80],
    'ramipril':         [1, 2, 5, 10],
    'atorvastatin':     [10, 20, 40, 80],
    'levothyroxine':    [25, 50, 75, 100, 125],
    'prednisolone':     [5, 10, 20],
    'dexamethasone':    [0, 5, 4],
    'salbutamol':       [2, 4],
    'montelukast':      [4, 5, 10],
    'gabapentin':       [100, 300, 400],
    'sertraline':       [25, 50, 100],
    'escitalopram':     [5, 10, 20],
    'alprazolam':       [0, 25, 0.5, 1],
    'vitamin d3':       [1000, 2000, 60000],
    'vitamin b12':      [500, 1000, 1500],
    'vitamin c':        [250, 500, 1000],
    'iron supplement':  [100, 150, 200],
    'folic acid':       [1, 5],
    'calcium carbonate':[500, 1000],
    'zinc supplement':  [10, 20, 50],
    'allopurinol':      [100, 300],
    'colchicine':       [0, 5, 1],
}

def snap_to_tablet(medicine_key, dose):
    """Snap calculated dose to nearest real tablet size available."""
    sizes = REAL_TABLET_SIZES.get(medicine_key.lower())
    if not sizes:
        return dose
    # Filter out zero values
    sizes = [s for s in sizes if s > 0]
    if not sizes:
        return dose
    return min(sizes, key=lambda s: abs(s - dose))

def calculate_safe_dosage(medicine_key, age, weight):
    med = MEDICINE_DATABASE.get(medicine_key.lower())
    if not med:
        return None, "Medicine not found"
    if age < 12:
        if med["child_dose"] == 0:
            return None, f"{med['name']} is NOT SAFE for children under 12"
        base_dose = med["child_dose"]; category = "pediatric"
    elif age > 65:
        base_dose = med["elderly_dose"]; category = "elderly"
    else:
        base_dose = med["adult_dose"]; category = "adult"
    # Snap to real tablet size
    base_dose = snap_to_tablet(medicine_key, base_dose)
    return int(base_dose), category

def check_drug_interactions(medicine_key, current_meds):
    warnings = []
    med = MEDICINE_DATABASE.get(medicine_key.lower())
    if not med: return warnings
    for cm in [m.strip().lower() for m in current_meds.split(',') if m.strip()]:
        if cm not in MEDICINE_DATABASE:
            # Medicine not in our DB — warn user we cannot check it
            warnings.append({"severity": "INFO",
                "message": f"ℹ️ NOTE: '{cm.title()}' is not in our database — interaction with {med['name']} could not be verified. Please consult your doctor."})
        elif cm in med["interactions"]:
            warnings.append({"severity": "HIGH",
                "message": f"⚠️ INTERACTION: {med['name']} may interact with {cm.title()}. Please consult your doctor before combining."})
    return warnings

def check_allergy_conflict(medicine_key, allergies):
    med = MEDICINE_DATABASE.get(medicine_key.lower())
    if not med: return None
    for a in [x.strip().lower() for x in allergies.split(',') if x.strip()]:
        if a in med["allergies"]:
            return {"severity": "CRITICAL",
                "message": f"🚫 ALLERGY RISK: Patient allergic to {a}. DO NOT USE {med['name']}!"}
    return None

def check_condition_conflict(medicine_key, conditions):
    warnings = []
    med = MEDICINE_DATABASE.get(medicine_key.lower())
    if not med: return warnings
    for cond in [c.strip().lower() for c in conditions.split(',') if c.strip()]:
        for avoid in med["conditions_avoid"]:
            if cond in avoid.lower() or avoid.lower() in cond:
                warnings.append({"severity": "HIGH",
                    "message": f"⚠️ CONTRAINDICATION: {med['name']} may worsen {cond.title()}"})
                break
    return warnings

def generate_explanation(medicine_key, age, disease, dosage, combo_medicines=None):
    med = MEDICINE_DATABASE.get(medicine_key.lower())
    if not med: return "Unable to generate explanation"
    if age < 12:   age_text = f"Paediatric dosage ({dosage}mg) calculated for child safety."
    elif age > 65: age_text = f"Reduced dosage ({dosage}mg) recommended for elderly patients."
    else:          age_text = f"Standard adult dosage ({dosage}mg) appropriate for your age group."

    # Build a reasoning line for EVERY medicine in the combo
    med_lines = ""
    if combo_medicines:
        for m in combo_medicines:
            use_clean = m["use"].replace("|", ", ")
            label = "Primary" if m.get("is_primary") else "Additional"
            med_lines += (
                f"<p>✅ <strong>{label} — {m['name']}</strong> ({m['category']}): "
                f"Treats <em>{use_clean}</em> — recommended for "
                f"<strong>{m['for_disease']}</strong>.</p>"
            )
    else:
        use_clean = med["use"].replace("|", ", ")
        med_lines = (
            f"<p>✅ <strong>Primary — {med['name']}</strong> ({med['category']}): "
            f"Treats <em>{use_clean}</em>.</p>"
        )

    return (
        f"<p><strong>Why these medicines were recommended:</strong></p>"
        f"{med_lines}"
        f"<p>✅ <strong>Age Factor:</strong> {age_text}</p>"
        f"<p>✅ <strong>Safety Profile:</strong> Each medicine is clinically proven "
        f"with a well-understood side effect profile.</p>"
    )

# ─────────────────────────────────────────────────────
# DISEASE → PRESCRIPTION LOGIC (Doctor Mode)
# ─────────────────────────────────────────────────────

DISEASE_PROTOCOLS = {
    'heart': {
        'diagnosis': 'Cardiac Chest Pain / Heart Condition',
        'detail': 'Chest pain or discomfort that may indicate a cardiac condition — requires urgent medical evaluation',
        'medicines': ['aspirin', 'atenolol'],
        'duration': 'As prescribed by cardiologist — do not self-medicate',
        'duration_note': '⚠️ URGENT: Chest pain always requires immediate medical attention. Go to emergency if pain is severe.',
        'advice': ['Seek emergency care immediately if chest pain is severe, crushing, or spreads to arm or jaw',
                   'Do NOT ignore chest pain — always get an ECG done urgently',
                   'Avoid all physical exertion until evaluated by a doctor',
                   'Note when pain started, how long it lasts, and what makes it better or worse',
                   'Aspirin 75mg is only for confirmed heart disease — do not take without doctor advice'],
        'diet': 'Heart-healthy diet — oats, salmon, walnuts, olive oil, fruits, vegetables, whole grains',
        'avoid': 'Salt, saturated fats, red meat, processed food, smoking, alcohol, excessive caffeine, physical stress'
    },
    'uti': {
        'diagnosis': 'Urinary Tract Infection (UTI)',
        'detail': 'Bacterial infection of the bladder or urinary tract requiring antibiotic therapy',
        'medicines': ['ciprofloxacin'],
        'duration': '5–7 days',
        'duration_note': 'Complete the full antibiotic course. Incomplete treatment causes recurrence.',
        'advice': ['Drink 2–3 litres of water daily to flush bacteria from the bladder',
                   'Urinate frequently — do not hold urine',
                   'See a doctor if fever develops alongside UTI symptoms',
                   'Complete the full 7-day course even if symptoms improve after 2 days'],
        'diet': 'Plenty of water, cranberry juice helps prevent recurrence, fresh fruits and vegetables',
        'avoid': 'Alcohol, caffeine, spicy food, carbonated drinks — these irritate the bladder'
    },
    'menstrual': {
        'diagnosis': 'Dysmenorrhea / Menstrual Pain',
        'detail': 'Painful menstruation requiring pain relief and anti-inflammatory therapy',
        'medicines': ['mefenamic acid', 'ibuprofen'],
        'duration': '3–5 days (during menstrual period only)',
        'duration_note': 'Take at the onset of pain for best effect. Do not take on an empty stomach.',
        'advice': ['Apply warm compress or hot water bottle to lower abdomen for pain relief',
                   'Gentle yoga and light walking helps reduce cramps',
                   'Track your cycle to anticipate and prepare',
                   'See a gynaecologist if pain is severe or affects daily activities'],
        'diet': 'Iron-rich foods during period — spinach, lentils, dates. Stay well hydrated.',
        'avoid': 'Alcohol, caffeine, salty processed foods, cold drinks — these worsen bloating and cramps'
    },
    'fungal': {
        'diagnosis': 'Fungal Skin Infection',
        'detail': 'Fungal overgrowth on skin requiring antifungal therapy',
        'medicines': ['clotrimazole'],
        'duration': '7–14 days',
        'duration_note': 'Complete the full course even if symptoms clear early. Stopping early causes recurrence.',
        'advice': ['Keep affected area clean and completely dry',
                   'Wear loose breathable cotton clothing',
                   'Do not share towels or clothing',
                   'Wash hands thoroughly after applying cream'],
        'diet': 'Reduce sugar and refined carbohydrates — fungus thrives on sugar. Eat probiotics like curd.',
        'avoid': 'Alcohol, sugar, yeast-containing foods like bread and beer during treatment'
    },
    'skin': {
        'diagnosis': 'Skin Infection / Dermatitis / Eczema',
        'detail': 'Inflammatory or infectious skin condition requiring topical treatment',
        'medicines': ['hydrocortisone', 'cetirizine'],
        'duration': '7–14 days',
        'duration_note': 'Do not use topical steroids for more than 14 days on the same area without medical review.',
        'advice': ['Keep skin clean and well moisturised',
                   'Avoid scratching — it worsens infection and spreads bacteria',
                   'Wear loose breathable cotton clothing',
                   'Identify and avoid skin irritants like harsh soaps and synthetic fabrics'],
        'diet': 'Anti-inflammatory foods — omega-3 fish, turmeric, green tea, plenty of water',
        'avoid': 'Known allergens, harsh soaps, synthetic fabrics, stress (worsens eczema)'
    },
    'congestion': {
        'diagnosis': 'Nasal Congestion / Sinusitis',
        'detail': 'Nasal inflammation and blockage requiring decongestant therapy',
        'medicines': ['cetirizine'],
        'duration': '3–5 days',
        'duration_note': 'If nasal decongestant spray is used, do not exceed 5 days — causes rebound congestion.',
        'advice': ['Steam inhalation with a few drops of eucalyptus oil 2–3 times daily',
                   'Saline nasal rinse helps clear congestion naturally',
                   'Elevate your head slightly while sleeping',
                   'Stay well hydrated — warm liquids help loosen congestion'],
        'diet': 'Warm soups, herbal teas with ginger and honey, warm water with lemon and honey',
        'avoid': 'Cold beverages, dairy products (thicken mucus), dusty environments, smoke'
    },
    'fever': {
        'diagnosis': 'Acute Fever / Pyrexia',
        'detail': 'Elevated body temperature indicating infection or inflammation',
        'medicines': ['paracetamol'],
        'duration': '3–5 days',
        'duration_note': 'Stop if fever resolves. See doctor if fever exceeds 39.5°C or lasts >3 days.',
        'advice': ['Rest and stay hydrated — drink 2–3 litres of water daily',
                   'Tepid sponging for high fever above 38.5°C',
                   'Monitor temperature every 4 hours',
                   'Seek emergency care if fever exceeds 40°C or seizures occur'],
        'diet': 'Light easily digestible food — soups, khichdi, fruits',
        'avoid': 'Oily, spicy food and cold drinks'
    },
    'cold': {
        'diagnosis': 'Upper Respiratory Tract Infection (Common Cold / Influenza)',
        'detail': 'Viral infection of the nose and throat',
        'medicines': ['cetirizine', 'paracetamol'],
        'duration': '5–7 days',
        'duration_note': 'See a doctor if symptoms worsen or last longer than 10 days.',
        'advice': ['Rest adequately and stay warm',
                   'Steam inhalation 2–3 times daily for nasal congestion',
                   'Warm salt water gargling for sore throat',
                   'Avoid exposure to cold air'],
        'diet': 'Warm soups, herbal teas with ginger and honey, warm water',
        'avoid': 'Cold beverages, ice cream, fried food'
    },
    'cough': {
        'diagnosis': 'Acute Cough / Bronchitis',
        'detail': 'Inflammatory condition of the airways',
        'medicines': ['azithromycin', 'paracetamol'],
        'duration': '5–7 days',
        'duration_note': 'If cough persists beyond 3 weeks, consult a pulmonologist.',
        'advice': ['Drink warm liquids frequently', 'Steam inhalation helps',
                   'Avoid irritants like smoke and dust', 'Sleep with head slightly elevated'],
        'diet': 'Honey with warm water, ginger tea, warm broths',
        'avoid': 'Dairy products (thickens mucus), cold drinks, smoking'
    },
    'infection': {
        'diagnosis': 'Bacterial Infection',
        'detail': 'Infection requiring antibiotic therapy',
        'medicines': ['amoxicillin'],
        'duration': '7 days',
        'duration_note': 'IMPORTANT: Complete the full 7-day course even if you feel better.',
        'advice': ['Complete the full antibiotic course — never stop early',
                   'Take at regular intervals to maintain steady blood levels',
                   'Do not share antibiotics with others',
                   'If allergic to penicillin, use Azithromycin instead'],
        'diet': 'Probiotics (yogurt/curd) to protect gut during antibiotics, plenty of fluids',
        'avoid': 'Alcohol (reduces antibiotic effectiveness), dairy 2 hours before/after dose'
    },
    'hypertension': {
        'diagnosis': 'Essential Hypertension (High Blood Pressure)',
        'detail': 'Sustained elevated blood pressure requiring management',
        'medicines': ['amlodipine'],
        'duration': 'Ongoing (as prescribed by doctor)',
        'duration_note': 'Do NOT stop this medicine without consulting your doctor. BP medicines are usually lifelong.',
        'advice': ['Monitor blood pressure daily at the same time',
                   'Exercise moderately — 30 minutes walking daily',
                   'Manage stress through yoga and meditation',
                   'Target BP below 130/80 mmHg'],
        'diet': 'Low-sodium DASH diet — fruits, vegetables, whole grains, low-fat dairy',
        'avoid': 'Salt, pickles, processed food, alcohol, smoking'
    },
    'diabetes': {
        'diagnosis': 'Type 2 Diabetes Mellitus',
        'detail': 'Elevated blood glucose levels requiring glycemic control',
        'medicines': ['metformin'],
        'duration': 'Ongoing (lifelong management)',
        'duration_note': 'Monitor blood sugar regularly. HbA1c target: below 7%.',
        'advice': ['Monitor fasting and post-meal blood sugar daily',
                   'Foot care — inspect daily for cuts or sores',
                   'Regular HbA1c test every 3 months',
                   'Exercise 30–45 minutes daily to improve insulin sensitivity'],
        'diet': 'High-fiber, low-glycemic foods — whole grains, vegetables, legumes',
        'avoid': 'Sugar, white rice, maida, sweet fruits (mango, banana), alcohol'
    },
    'allergy': {
        'diagnosis': 'Allergic Reaction / Allergic Rhinitis',
        'detail': 'Immune hypersensitivity response to allergens',
        'medicines': ['cetirizine'],
        'duration': '7–14 days',
        'duration_note': 'Continue until symptoms fully clear. For seasonal allergy, take daily during season.',
        'advice': ['Identify and avoid your specific allergen triggers',
                   'Wear mask in dusty or polluted environments',
                   'Keep windows closed during high pollen season',
                   'Wash hands frequently'],
        'diet': 'Anti-inflammatory foods — turmeric milk, ginger, leafy vegetables',
        'avoid': 'Known allergens, alcohol (worsens histamine reaction), processed food'
    },
    'acidity': {
        'diagnosis': 'Gastroesophageal Reflux Disease (GERD) / Acidity',
        'detail': 'Excess stomach acid causing heartburn and discomfort',
        'medicines': ['omeprazole'],
        'duration': '7–14 days',
        'duration_note': 'Take before breakfast for best results. Long-term use needs doctor supervision.',
        'advice': ['Eat smaller, more frequent meals',
                   'Do not lie down for 2 hours after eating',
                   'Elevate head of bed by 6–8 inches if nighttime reflux',
                   'Lose weight if overweight — reduces abdominal pressure'],
        'diet': 'Small frequent meals, non-citrus fruits, vegetables, lean protein',
        'avoid': 'Spicy food, citrus fruits, coffee, alcohol, tomatoes, chocolate, fatty food'
    },
    'pain': {
        'diagnosis': 'Acute Pain / Musculoskeletal Pain',
        'detail': 'Inflammatory or nociceptive pain requiring analgesia',
        'medicines': ['ibuprofen'],
        'duration': '3–5 days',
        'duration_note': 'Do not take on empty stomach. Stop if stomach pain occurs.',
        'advice': ['Rest the affected area',
                   'Apply ice pack for first 48 hours, then warm compress',
                   'Gentle stretching after pain reduces',
                   'See a doctor if pain is severe or persistent'],
        'diet': 'Anti-inflammatory foods — omega-3 rich fish, turmeric, ginger',
        'avoid': 'Alcohol (increases bleeding risk with ibuprofen), heavy physical activity'
    },
    'migraine': {
        'diagnosis': 'Migraine Headache',
        'detail': 'Recurrent moderate-to-severe headache, often unilateral with nausea',
        'medicines': ['ibuprofen'],
        'duration': 'Per episode (take at onset of headache)',
        'duration_note': 'Take medicine at the very first sign of migraine for best effect.',
        'advice': ['Rest in a dark, quiet room during attack',
                   'Apply cold or warm compress on forehead',
                   'Keep a migraine diary to identify triggers',
                   'Maintain regular sleep schedule — irregular sleep triggers migraines'],
        'diet': 'Regular meals (skipping meals triggers migraine), stay well-hydrated',
        'avoid': 'Caffeine, alcohol, aged cheese, processed meats, bright lights, loud noise'
    },
    'thyroid': {
        'diagnosis': 'Hypothyroidism (Underactive Thyroid)',
        'detail': 'Insufficient thyroid hormone production',
        'medicines': ['levothyroxine'],
        'duration': 'Lifelong (as prescribed)',
        'duration_note': 'Take on EMPTY STOMACH, 30 minutes before breakfast. Never skip doses.',
        'advice': ['Take medicine at the same time every morning',
                   'TSH blood test every 6 months to adjust dose',
                   'Do not take with calcium, iron or antacids — wait 4 hours',
                   'Inform dentist/surgeon you are on thyroid medicine'],
        'diet': 'Selenium-rich foods — nuts, fish. Iodized salt in moderation',
        'avoid': 'Raw cruciferous vegetables (broccoli, kale) in excess, soy products near dose time'
    },
    'cholesterol': {
        'diagnosis': 'Hyperlipidemia (High Cholesterol)',
        'detail': 'Elevated LDL cholesterol increasing cardiovascular risk',
        'medicines': ['atorvastatin'],
        'duration': 'Ongoing (usually lifelong)',
        'duration_note': 'Take at night — cholesterol is produced most at night. Do not stop without doctor advice.',
        'advice': ['Lipid panel blood test every 3–6 months',
                   'Exercise 30–45 minutes daily',
                   'Maintain healthy weight',
                   'Watch for muscle pain (rare side effect) — report to doctor'],
        'diet': 'Oats, nuts, olive oil, fatty fish (salmon, mackerel), fruits and vegetables',
        'avoid': 'Saturated fats, trans fats, red meat, full-fat dairy, fried food, grapefruit juice'
    },
    'stomach': {
        'diagnosis': 'Gastritis / Nausea / Vomiting',
        'detail': 'Stomach inflammation or gastrointestinal upset',
        'medicines': ['ondansetron', 'omeprazole'],
        'duration': '3–5 days',
        'duration_note': 'If vomiting is severe or blood is present, seek emergency care.',
        'advice': ['Stay hydrated — sip ORS or coconut water slowly',
                   'Rest and avoid physical exertion',
                   'Start with bland food once vomiting settles',
                   'Seek care if unable to keep any liquids down for >8 hours'],
        'diet': 'BRAT diet — Banana, Rice, Apple (cooked), Toast. ORS for hydration',
        'avoid': 'Spicy, oily, fried food. Dairy. Coffee. Alcohol.'
    },
    'vitamin': {
        'diagnosis': 'Vitamin / Nutritional Deficiency',
        'detail': 'Micronutrient deficiency requiring supplementation',
        'medicines': ['vitamin d3', 'vitamin b12'],
        'duration': '3 months initially',
        'duration_note': 'Recheck blood levels after 3 months. Continue if still deficient.',
        'advice': ['Vitamin D: Sun exposure 15–20 minutes daily (9–11 AM)',
                   'B12: Especially important for vegetarians',
                   'Take with meals to improve absorption',
                   'Get blood levels tested before and after supplementation'],
        'diet': 'Vitamin D: Fatty fish, egg yolk, fortified milk. B12: Eggs, dairy, meat',
        'avoid': 'Excess supplementation without testing — can be toxic (especially Vitamin D)'
    }
}

def autocorrect_text(text):
    corrections = {
        'faver':'fever','feaver':'fever','fevr':'fever','feve':'fever',
        'headach':'headache','hedache':'headache','migrane':'migraine',
        'stomache':'stomach','stomac':'stomach','stomak':'stomach','stomachh':'stomach',
        'diabetis':'diabetes','diabeties':'diabetes','suger':'sugar',
        'presure':'pressure','colestrol':'cholesterol','cholestrol':'cholesterol',
        'thyord':'thyroid','thyriod':'thyroid','thiroid':'thyroid',
        'alergy':'allergy','allergi':'allergy','alregy':'allergy',
        'infecton':'infection','vomting':'vomiting','vomitting':'vomiting',
        'diarea':'diarrhea','diarrea':'diarrhea','diarhea':'diarrhea',
        'coff':'cough','caugh':'cough','coughh':'cough',
        'hearth':'heart','herat':'heart','haert':'heart',
        'acedity':'acidity','acidty':'acidity',
        'painn':'pain','throatt':'throat','feverr':'fever',
        'weaknes':'weakness','weekness':'weakness',
        'pnemonia':'pneumonia','hypertenshion':'hypertension',
    }
    words = text.lower().split()
    result = ' '.join([corrections.get(w, w) for w in words])
    for k, v in corrections.items():
        if ' ' in k and k in result:
            result = result.replace(k, v)
    return result


def identify_disease(problem_text):
    results = identify_all_diseases(problem_text)
    return results[0] if results else 'fever'


def identify_all_diseases(problem_text):
    """
    Rule-based NLP symptom classifier.
    Steps:
      1. Normalise & autocorrect the text
      2. Expand contractions and casual English phrases
      3. Match against a rich symptom pattern set (keywords + phrase patterns)
      4. Partial-word fallback for any remaining unmatched words
    Works entirely offline — no API needed.
    """
    import re

    # ── Step 1: Normalise ────────────────────────────────────────────────────
    p = autocorrect_text(problem_text.lower().strip())

    # ── Step 2: Expand contractions & casual phrases ─────────────────────────
    expansions = {
        "i'm":         "i am",
        "i've":        "i have",
        "i've been":   "i have been",
        "can't":       "cannot",
        "don't":       "do not",
        "it's":        "it is",
        "won't":       "will not",
        "they're":     "they are",
        "doesn't":     "does not",
        "isn't":       "is not",
        "wasn't":      "was not",
        "aren't":      "are not",
        "haven't":     "have not",
        "couldn't":    "could not",
        "shouldn't":   "should not",
        "there's":     "there is",
        "that's":      "that is",
        "let's":       "let us",
        "i'd":         "i would",
        "he's":        "he is",
        "she's":       "she is",
        "you're":      "you are",
        "we're":       "we are",
        # casual body phrases
        "my tummy":    "my stomach",
        "tummy ache":  "stomach ache",
        "tummy pain":  "stomach pain",
        "belly ache":  "stomach ache",
        "belly pain":  "stomach pain",
        "paining":     "pain",
        "pains me":    "pain",
        "feel sick":   "nausea",
        "feeling sick":"nausea",
        "threw up":    "vomited",
        "throwing up": "vomiting",
        "threw out":   "vomited",
        "going to vomit":"vomiting",
        "burning pee": "burning urination",
        "pee burns":   "burning urination",
        "pee a lot":   "frequent urination",
        "pee often":   "frequent urination",
        "runny eyes":  "watery eyes",
        "watery nose": "runny nose",
        "runny water": "runny nose",
        "loose potty": "loose motion",
        "loose poop":  "loose stool",
        "watery poop": "diarrhea",
        "motion problem":"loose motion",
        "going toilet a lot":"frequent urination",
        "toilet again and again":"frequent urination",
        "sugar is up":  "blood sugar high",
        "sugar went up":"blood sugar high",
        "bp is up":     "blood pressure high",
        "bp went up":   "blood pressure high",
        "heart beating fast":"heart racing",
        "heart beats fast":  "heart racing",
        "hair coming out":   "hair loss",
        "hair falling out":  "hair loss",
        "hair dropping":     "hair loss",
        "no appetite":       "loss of appetite",
        "not hungry":        "loss of appetite",
        "cannot eat":        "loss of appetite",
        "on fire":    "burning fever",
        "burning up": "fever",
    }
    for phrase, replacement in expansions.items():
        p = p.replace(phrase, replacement)

    # ── Step 3: Block stomach/acidity when cardiac signals present ────────────
    heart_signals = ['heart pain','heart attack','cardiac','chest pain','chest tightness',
                     'chest pressure','palpitation','left arm pain','angina','heart racing',
                     'crushing chest pain']
    excluded = set()
    if any(sig in p for sig in heart_signals):
        excluded.update(['stomach', 'acidity'])

    # ── Step 4: Symptom pattern matching ─────────────────────────────────────
    # Each entry is a list of patterns — single words OR multi-word phrases.
    # Multi-word phrases are matched as substrings.
    # Single words are matched as whole words (no partial matches).
    symptoms = {
        'fever': [
            'fever','temperature','pyrexia','chills','shivering','sweating',
            'hot body','body heat','feeling hot','body is hot','feeling warm',
            'burning up','running a temperature','high temp','mild fever',
            'feeling feverish','body temperature high','high temperature',
            'temperature is high','i have fever','got fever','had fever',
            'continuous fever','on and off fever','low grade fever',
        ],
        'migraine': [
            'headache','migraine','throbbing','head pain','head ache',
            'my head hurts','head hurts','head is hurting','head is pounding',
            'head is splitting','terrible headache','head is killing me',
            'head feels heavy','head is throbbing','forehead pain',
            'temple pain','skull pain','one side head','one side of head',
            'pain in the head','head spinning','head reeling',
            'pounding head','splitting headache','head is bursting',
        ],
        'pain': [
            'body pain','joint pain','muscle pain','back pain','body ache',
            'arthritis','sprain','knee pain','neck pain','shoulder pain',
            'leg pain','arm pain','hip pain','my body is aching',
            'pain all over','everything hurts','bones are hurting',
            'my back hurts','lower back pain','stiff neck','stiff joints',
            'muscle cramp','sharp pain','dull ache','pain in my',
            'hurts when i','aching all over','whole body aches',
            'body is aching','bone pain','joint is swollen','swollen joint',
        ],
        'cold': [
            'cold','flu','runny nose','sneezing','sore throat','rhinitis',
            'influenza','stuffy nose','blocked nose','nasal congestion',
            'my nose is running','nose keeps running','cannot stop sneezing',
            'sneezing a lot','throat is hurting','throat is sore',
            'throat feels scratchy','my throat hurts','nose is blocked',
            'cannot breathe through nose','throat pain','nose running',
            'watery nose','post nasal drip','nose dripping',
            'i have cold','caught cold','got a cold','having cold',
        ],
        'cough': [
            'cough','bronchitis','phlegm','mucus','wheezing','dry cough',
            'wet cough','cannot stop coughing','coughing a lot',
            'cough with phlegm','chest feels heavy','hard to breathe',
            'difficulty breathing','breathless','short of breath',
            'persistent cough','chest congestion','coughing since',
            'cough since','continuous cough','morning cough',
            'night cough','coughing blood','i have cough',
        ],
        'allergy': [
            'allergy','allergic','rash','hives','urticaria','itching','itchy',
            'watery eyes','skin rash','skin irritation','my skin is itchy',
            'skin keeps itching','red spots on skin','red bumps on skin',
            'eyes are watery','eyes keep watering','sneezing from dust',
            'allergic to something','swollen lips','itchy throat',
            'itchy eyes','skin turned red','allergic reaction',
            'dust allergy','food allergy','seasonal allergy',
            'eyes itching','nose itching','throat itching',
        ],
        'acidity': [
            'acidity','acid reflux','heartburn','gerd','bloating',
            'indigestion','gastric','sour belching','burning stomach',
            'burning chest','stomach is burning','acid coming up',
            'sour taste','burping a lot','cannot digest food',
            'feel full quickly','belching','gas after eating',
            'burning after eating','chest burning after food',
            'food not digesting','undigested food','stomach acid',
            'acid problem','acidity problem','gastric problem',
            'belching frequently','frequent burping',
        ],
        'stomach': [
            'nausea','vomiting','vomit','vomited','gastritis',
            'stomach ache','stomach pain','stomach cramp',
            'abdominal pain','belly pain','tummy pain','diarrhea',
            'diarrhoea','loose motion','loose stool','watery stool',
            'upset stomach','food poisoning','gut pain','bowel pain',
            'feel like throwing up','want to vomit','feeling nauseous',
            'stomach is upset','my stomach hurts','stomach is paining',
            'ate bad food','going to toilet again','watery motion',
            'cannot keep food down','motion is watery','stomach trouble',
            'stomach issue','stomach problem','tummy trouble',
            'intestinal pain','intestine pain','pain in abdomen',
            'abdominal cramp','stomach grumbling','gurgling stomach',
        ],
        'heart': [
            'heart pain','heart attack','cardiac','chest pain','heart disease',
            'palpitation','heart racing','irregular heartbeat','angina',
            'myocardial','heart problem','chest tightness','left arm pain',
            'chest pressure','my heart is racing','heart is beating fast',
            'heart is pounding','heart is skipping beats',
            'feel like heart attack','pressure on chest',
            'heavy feeling on chest','chest feels tight',
            'squeezing in chest','pain spreading to arm','heart fluttering',
            'heart condition','irregular heart','heart pounding',
        ],
        'hypertension': [
            'blood pressure','hypertension','bp high','high bp','diastolic',
            'systolic','my bp is high','bp reading is high',
            'i have high blood pressure','pressure is not controlled',
            'bp problem','pressure is high','bp elevated',
            'blood pressure high','high blood pressure',
            'bp not controlled','bp fluctuating',
        ],
        'diabetes': [
            'diabetes','blood sugar','glucose','sugar level','hba1c',
            'fasting sugar','diabetic','my sugar is high',
            'sugar level is not controlled','i have diabetes',
            'thirsty all the time','urinating too much','peeing a lot',
            'always hungry','sugar is high','blood glucose high',
            'sugar problem','diabetes problem','diabetic patient',
            'sugar not controlled','fasting glucose',
        ],
        'infection': [
            'infection','bacteria','pus','abscess','wound infected',
            'bacterial','skin infection','sepsis',
            'wound is not healing','cut is infected','pus coming out',
            'swollen and red','boil on skin','infected wound',
            'wound not healing','getting infected','spreading infection',
            'infected cut','infected sore',
        ],
        'uti': [
            'uti','urinary tract','burning urination','frequent urination',
            'bladder infection','painful urination','cloudy urine',
            'cystitis','burning when i pee','it burns when peeing',
            'pain while urinating','going to toilet very often',
            'urine is cloudy','urine smells bad','cannot hold urine',
            'urge to pee all the time','blood in urine',
            'urinary infection','burning sensation urine',
            'pain in bladder','lower abdomen pain urination',
        ],
        'thyroid': [
            'thyroid','hypothyroid','hyperthyroid','tsh','goiter',
            'thyroid problem','gaining weight for no reason',
            'losing weight for no reason','always tired and cold',
            'hair is falling','hair loss','feel sluggish all day',
            'neck is swollen','thyroid issue','thyroid condition',
            'weight gain without reason','unexplained weight loss',
            'always feeling cold','cold intolerance','heat intolerance',
        ],
        'cholesterol': [
            'cholesterol','lipid','hdl','ldl','triglyceride',
            'high cholesterol','my cholesterol is high',
            'doctor said cholesterol is bad','bad cholesterol',
            'cholesterol problem','cholesterol not controlled',
            'fatty liver','high lipid',
        ],
        'vitamin': [
            'vitamin d','vitamin b','vitamin c','deficiency','anemia',
            'weak bones','iron deficiency','feeling very weak',
            'always tired','no energy at all','feel exhausted all the time',
            'tired even after sleeping','feel drained',
            'body feels heavy all day','fatigue all day','lethargic',
            'getting tired quickly','brain fog','dizzy when standing up',
            'constantly tired','weakness','general weakness',
            'tired all day','lack of energy','energy is low',
            'bones are weak','brittle bones','pale skin',
        ],
        'menstrual': [
            'menstrual pain','period pain','dysmenorrhea','menstrual cramps',
            'heavy periods','periods','monthly pain','heavy bleeding period',
            'period cramps','cramps during period','cannot work during periods',
            'backache during periods','irregular periods','periods are late',
            'time of month','monthly cycle pain','menses','menstruation',
            'missed period','delayed period','period not coming',
            'period blood clots','severe period pain','pcod','pcos',
        ],
        'skin': [
            'eczema','dermatitis','psoriasis','impetigo',
            'skin inflammation','skin is peeling','skin is dry and cracked',
            'skin is red and itchy','patches on skin','scaly skin',
            'flaky skin','redness on skin','skin breakout','recurring rash',
            'dry skin','cracked skin','skin flaking','skin scaling',
            'skin lesion','skin ulcer','blister on skin',
        ],
        'fungal': [
            'fungal','fungus','candida','thrush','ringworm','athlete foot',
            'nail fungus','round patch on skin','circular rash',
            'ring shaped rash','white patches in mouth','itchy between toes',
            'nails turning yellow','groin itching','inner thigh itching',
            'fungal infection','yeast infection','white discharge',
            'nail infection','toe nail fungus',
        ],
        'congestion': [
            'sinusitis','sinus blocked','sinus headache','pressure behind eyes',
            'nose block since days','cannot smell anything','loss of smell',
            'face feels heavy','nasal congestion since days',
            'sinus pain','sinus pressure','blocked sinuses',
            'sinus drainage','post nasal drip','sinus infection',
            'pressure in face','cheekbone pain','forehead pressure',
        ],
    }

    BOOST = {
        'heart':       15,
        'hypertension': 5,
        'diabetes':     5,
        'thyroid':      5,
        'acidity':      8,
        'menstrual':    8,
        'uti':          8,
    }

    def match(kw, text):
        """Whole-word match for single words, substring for phrases."""
        if ' ' in kw:
            return kw in text
        return bool(re.search(r'(?<![a-z])' + re.escape(kw) + r'(?![a-z])', text))

    scores = {}
    for disease, patterns in symptoms.items():
        if disease in excluded:
            continue
        score = sum(1 for kw in patterns if match(kw, p))
        if score > 0:
            scores[disease] = score + BOOST.get(disease, 0)

    # ── Step 5: Partial-word fallback for short/vague inputs ─────────────────
    if not scores:
        roots = {
            'stomach':     ['stomach','abdomen','abdom','belly','tummy','gut','nausea','vomit','puke','bowel'],
            'pain':        ['pain','ache','hurt','sore','cramp','spasm','tender','throb'],
            'fever':       ['fever','hot','temp','warm','burn','sweat','chill'],
            'cold':        ['cold','sneez','throat','nasal','mucus','runny','stuffy'],
            'cough':       ['cough','wheez','phlegm','bronch','breath'],
            'allergy':     ['itch','rash','hive','urtic','allerg','swell'],
            'acidity':     ['acid','gastric','belch','burp','digest','reflux'],
            'heart':       ['heart','cardiac','chest','palpitat'],
            'hypertension':['pressure','hyper','bp'],
            'diabetes':    ['diabet','sugar','glucose','insulin'],
            'vitamin':     ['tired','weak','fatigue','exhaust','energy','vitamin','anaem','anemia'],
            'thyroid':     ['thyroid','tsh','sluggish','goiter'],
            'uti':         ['urin','bladder','pee','piss','cystit'],
            'infection':   ['infect','pus','abscess','bacteria','wound'],
            'skin':        ['skin','dermati','eczema','psorias'],
            'fungal':      ['fungal','fungus','candida','ringworm','thrush'],
            'congestion':  ['sinus','nasal block','congestion'],
        }
        for disease, root_list in roots.items():
            if disease in excluded:
                continue
            for word in p.split():
                if any(word.startswith(rt) or rt in word for rt in root_list):
                    scores[disease] = scores.get(disease, 0) + 1

    if not scores:
        return ['pain']

    return sorted(scores.keys(), key=lambda d: scores[d], reverse=True)

# Disease severity baseline — used for score even when no interactions/conditions entered
DISEASE_SEVERITY = {
    'fever':        10,   # moderate — common, manageable
    'migraine':     12,
    'pain':         10,
    'cold':          8,
    'cough':        10,
    'allergy':       8,
    'acidity':       8,
    'stomach':      12,
    'hypertension': 18,   # chronic — always needs monitoring
    'diabetes':     20,
    'infection':    15,
    'thyroid':      15,
    'cholesterol':  12,
    'vitamin':       5,
    'uti':          14,
}


# ─────────────────────────────────────────────────────
# ROUTES
# ─────────────────────────────────────────────────────

@app.route('/')
def home():
    if 'user' in session:
        return redirect(url_for('main_app'))
    return redirect(url_for('login_page'))

@app.route('/app')
def main_app():
    if 'user' not in session:
        return redirect(url_for('login_page'))
    medicine_list = sorted(MEDICINE_DATABASE.keys())
    return render_template('index.html', medicines=medicine_list, user=session.get('user'))

@app.route('/login', methods=['GET','POST'])
def login_page():
    if request.method == 'POST':
        # Detect JSON vs form POST
        if request.content_type and 'application/json' in request.content_type:
            data = request.get_json() or {}
        else:
            data = request.form.to_dict()

        action = data.get('action','').strip()
        email  = data.get('email','').strip().lower()
        name   = data.get('name','').strip()
        pwd    = data.get('password','')
        users  = load_users()

        if action == 'register':
            if email in users:
                return jsonify({'ok': False, 'msg': 'Email already registered. Please login.'})
            if len(pwd) < 6:
                return jsonify({'ok': False, 'msg': 'Password must be at least 6 characters.'})
            users[email] = {'name': name, 'password': pwd, 'history': []}
            save_users(users)
            return jsonify({'ok': True, 'msg': 'Account created! Please login with your credentials.'})

        elif action in ('login', 'form_login'):
            u = users.get(email)
            if not u:
                return jsonify({'ok': False, 'msg': 'No account found. Please register first.'})
            if u['password'] != pwd:
                return jsonify({'ok': False, 'msg': 'Wrong password. Try again.'})
            # Set session directly — single step, no need for do_login redirect
            session.clear()
            session['user'] = {'email': email, 'name': u['name']}
            session.permanent = True
            session.modified = True
            return jsonify({'ok': True, 'msg': 'Welcome back, ' + u['name'], 'email': email, 'name': u['name'], 'redirect': '/app'})

    return render_template('login.html')


@app.route('/do_login', methods=['POST', 'GET'])
def do_login():
    """Fallback login redirect — sets session if not already set."""
    email = request.form.get('email','') or request.args.get('email','')
    name  = request.form.get('name','')  or request.args.get('name','')
    email = email.strip().lower()
    name  = name.strip()
    if email and name:
        session['user'] = {'email': email, 'name': name}
        session.permanent = True
        session.modified = True
    if 'user' in session:
        return redirect(url_for('main_app'))
    return redirect(url_for('login_page'))


@app.route('/logout')
def logout():
    session.pop('user', None)
    return redirect(url_for('login_page'))


@app.route('/history')
def history_page():
    if 'user' not in session:
        return redirect(url_for('login_page'))
    users   = load_users()
    email   = session['user']['email']
    history = users.get(email, {}).get('history', [])
    return render_template('history.html', user=session['user'], history=history)


@app.route('/save_history', methods=['POST'])
def save_history():
    if 'user' not in session:
        return jsonify({'ok': False})
    data  = request.get_json() or {}
    users = load_users()
    email = session['user']['email']
    if email not in users:
        users[email] = {'name': session['user']['name'], 'password': '', 'history': []}
    users[email]['history'].append({
        'date':     data.get('date', ''),
        'type':     data.get('type', 'safety_check'),
        'symptoms': data.get('symptoms', ''),
        'medicine': data.get('medicine', ''),
        'score':    data.get('score', None),
        'status':   data.get('status', ''),
        'age':      data.get('age', ''),
        'weight':   data.get('weight', ''),
    })
    users[email]['history'] = users[email]['history'][-50:]
    save_users(users)
    return jsonify({'ok': True})


@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/dashboard')
def dashboard():
    if 'user' not in session:
        return redirect(url_for('login_page'))
    categories = {}
    for med in MEDICINE_DATABASE.values():
        cat = med.get('category', 'Unknown')
        categories[cat] = categories.get(cat, 0) + 1
    stats = {"total_medicines": len(MEDICINE_DATABASE), "total_categories": len(categories), "categories": categories}
    return render_template('pages/dashboard.html', stats=stats)


# ── Safety Check ──────────────────────────────────────

@app.route('/check_medication', methods=['POST'])
def check_medication():
    # Keep session alive
    session.modified = True
    # Get user from session OR from form hidden field
    user = session.get('user')
    if not user:
        # Try to recover from form
        form_email = request.form.get('_user_email', '')
        form_name  = request.form.get('_user_name', '')
        if form_email and form_name:
            user = {'email': form_email, 'name': form_name}
            session['user'] = user
            session.permanent = True
            session.modified = True
        else:
            return redirect(url_for('login_page'))
    try:
        name         = request.form.get('name', 'Patient')
        age          = int(request.form.get('age', 0))
        weight       = float(request.form.get('weight', 0))
        disease      = request.form.get('disease', '').strip()
        current_meds = request.form.get('current_meds', '')
        allergies    = request.form.get('allergies', '')
        conditions   = request.form.get('conditions', '')

        if age <= 0 or weight <= 0 or not disease:
            return render_template('result.html', error="Please fill in your name, age, weight and describe your symptoms.", user=session.get('user'))

        # Patient profile
        patient_allergies  = [a.strip().lower() for a in allergies.split(',') if a.strip()]
        patient_meds       = [m.strip().lower() for m in current_meds.split(',') if m.strip()]
        patient_conditions = [c.strip().lower() for c in conditions.split(',') if c.strip()]

        # STEP 1: Detect ALL diseases/symptoms from description
        detected_diseases = identify_all_diseases(disease)

        # STEP 2: For each disease, pick the safest medicine for THIS patient
        def best_med_for(dk):
            protocol   = DISEASE_PROTOCOLS.get(dk, DISEASE_PROTOCOLS['fever'])
            candidates = protocol.get('medicines', ['paracetamol'])
            best_k, best_s = None, -999
            for cand in candidates:
                mk = cand.lower().strip()
                if mk not in MEDICINE_DATABASE:
                    continue
                med = MEDICINE_DATABASE[mk]
                # Hard blocks
                blocked = False
                for a in patient_allergies:
                    if any(a in al.lower() for al in med['allergies']):
                        blocked = True; break
                if blocked: continue
                if age < 12 and float(med.get('child_dose', 0)) == 0:
                    continue
                sc = 100
                for pm in patient_meds:
                    if any(pm in i.lower() for i in med['interactions']):
                        sc -= 30
                for pc in patient_conditions:
                    if any(pc in ca.lower() for ca in med['conditions_avoid']):
                        sc -= 25
                if age < 12:
                    sc += 10 if float(med.get('child_dose', 0)) > 0 else -20
                elif age > 65:
                    sc += 5
                if weight < 40:
                    sc -= 5
                if sc > best_s:
                    best_s = sc; best_k = mk
            # Disease-aware fallback — never give paracetamol for cardiac/serious conditions
            SAFE_FALLBACKS = {
                'heart':        'aspirin',
                'hypertension': 'amlodipine',
                'diabetes':     'metformin',
                'cholesterol':  'atorvastatin',
                'thyroid':      'levothyroxine',
                'uti':          'ciprofloxacin',
                'menstrual':    'mefenamic acid',
                'acidity':      'omeprazole',
                'stomach':      'ondansetron',
                'infection':    'amoxicillin',
            }
            return best_k or SAFE_FALLBACKS.get(dk, 'paracetamol')

        # Collect unique medicines per detected disease (max 3)
        seen_meds, combo_diseases = [], []
        for dk in detected_diseases[:3]:
            mk = best_med_for(dk)
            if mk not in seen_meds:
                seen_meds.append(mk)
                combo_diseases.append(dk)

        primary_med_key = seen_meds[0] if seen_meds else 'paracetamol'
        primary_disease = combo_diseases[0] if combo_diseases else detected_diseases[0]

        if primary_med_key not in MEDICINE_DATABASE:
            return render_template('result.html', error="No suitable medicine found. Please consult a doctor.", user=session.get('user'))

        med_info = MEDICINE_DATABASE[primary_med_key]

        # Allergy gate on primary
        allergy_warning = check_allergy_conflict(primary_med_key, allergies)
        if allergy_warning:
            return render_template('result.html',
                status="🚫 CRITICAL - DO NOT USE", medicine=med_info['name'],
                critical_warning=allergy_warning['message'], error_mode=True, user=session.get('user'))

        # STEP 3: Personalised dosage
        dosage, age_category = calculate_safe_dosage(primary_med_key, age, weight)
        if dosage is None:
            dosage = med_info['adult_dose']; age_category = "Adult"

        # STEP 4: Safety checks
        interaction_warnings = check_drug_interactions(primary_med_key, current_meds)
        condition_warnings   = check_condition_conflict(primary_med_key, conditions)

        # STEP 5: Dynamic safety score — reflects disease severity + patient factors
        base_deduction = DISEASE_SEVERITY.get(primary_disease, 10)
        safety_score   = 100 - base_deduction          # disease severity baseline

        if age < 12:           safety_score -= 8       # pediatric risk
        elif age > 65:         safety_score -= 7       # elderly risk
        if weight < 40:        safety_score -= 8       # very low weight
        elif weight < 50:      safety_score -= 4       # low weight

        safety_score -= len(interaction_warnings) * 20  # drug interactions
        safety_score -= len(condition_warnings)   * 15  # contraindications

        if len(patient_meds) == 1:    safety_score -= 3   # polypharmacy
        elif len(patient_meds) == 2:  safety_score -= 6
        elif len(patient_meds) >= 3:  safety_score -= 12

        if len(detected_diseases) == 2:  safety_score -= 5   # multiple symptoms
        elif len(detected_diseases) >= 3: safety_score -= 10

        safety_score = max(30, min(95, safety_score))

        status       = "⚠️ CAUTION REQUIRED" if (interaction_warnings or condition_warnings) else "✅ SAFE TO USE"
        status_class = "warning"              if (interaction_warnings or condition_warnings) else "safe"

        # STEP 6: Build per-disease medicine combo details
        combo_medicines = []
        for i, (mk, dk) in enumerate(zip(seen_meds, combo_diseases)):
            if mk not in MEDICINE_DATABASE:
                continue
            m    = MEDICINE_DATABASE[mk]
            d, _ = calculate_safe_dosage(mk, age, weight)
            if d is None: d = m['adult_dose']
            proto = DISEASE_PROTOCOLS.get(dk, {})
            combo_medicines.append({
                'name':        m['name'],
                'category':    m['category'],
                'use':         m['use'],
                'dosage':      d,
                'for_disease': dk.title(),
                'food_avoid':  m['food_avoid'],
                'food_take':   m['food_take'],
                'side_effects':m['side_effects'],
                'diet':        proto.get('diet', ''),
                'avoid_foods': proto.get('avoid', ''),
                'is_primary':  i == 0,
            })

        # Generate explanation AFTER combo_medicines is built so all medicines are included
        explanation = generate_explanation(primary_med_key, age, disease, dosage, combo_medicines=combo_medicines)

        detected_str = " + ".join([d.title() for d in detected_diseases[:3]])
        ai_reason = (
            f"AI detected <strong>{detected_str}</strong> from your description. "
            f"Recommended <strong>{', '.join([c['name'] for c in combo_medicines])}</strong> "
            f"— personalised for age {age} yrs, weight {weight} kg."
        )

        result = {
            'patient_name':         name,
            'status':               status,
            'status_class':         status_class,
            'safety_score':         safety_score,
            'medicine':             med_info['name'],
            'category':             med_info['category'],
            'use':                  med_info['use'],
            'dosage':               dosage,
            'max_daily':            med_info['max_daily'],
            'side_effects':         med_info['side_effects'],
            'food_avoid':           med_info['food_avoid'],
            'food_take':            med_info['food_take'],
            'combo_medicines':      combo_medicines,
            'detected_diseases':    detected_diseases[:3],
            'interaction_warnings': interaction_warnings,
            'condition_warnings':   condition_warnings,
            'explanation':          explanation,
            'age_category':         age_category,
            'ai_reason':            ai_reason,
            'recommended_for':      disease,
            # Patient inputs — shown in safety reasoning panel
            'patient_meds':         patient_meds,
            'patient_allergies':    patient_allergies,
            'patient_conditions':   patient_conditions,
            'age':                  age,
            'weight':               weight,
        }
        return render_template('result.html', result=result, user=session.get('user'))

    except ValueError:
        return render_template('result.html', error="Invalid input: Please enter valid numbers for age and weight.", user=session.get('user'))
    except Exception as e:
        return render_template('result.html', error=f"An error occurred: {str(e)}", user=session.get('user'))


@app.route('/prescription')
def prescription_page():
    if 'user' not in session:
        return redirect(url_for('login_page'))
    return render_template('prescription.html', user=session.get('user'))


@app.route('/get_prescription', methods=['POST'])
def get_prescription():
    """Doctor AI — gives full prescription based on described disease. No default questions."""
    try:
        data     = request.get_json()
        problem  = data.get('problem', '').strip()
        name     = data.get('name', 'Patient').strip()
        age      = int(data.get('age', 25))
        weight   = float(data.get('weight', 65))
        allergies = data.get('allergies', '').strip()

        if not problem:
            return jsonify({"error": "Please describe your symptoms or disease."})

        # ── Detect ALL diseases from description ──────────────────────
        detected_diseases = identify_all_diseases(problem)

        # Age group
        if age < 12:   age_group = "Child (Pediatric)"
        elif age > 65: age_group = "Elderly"
        else:          age_group = "Adult"

        patient_allergies = [a.strip().lower() for a in allergies.split(',') if a.strip()]

        def build_med_entry(med_key, for_disease):
            """Build a medicine schedule entry for one medicine"""
            med_key = med_key.lower().strip()
            if med_key not in MEDICINE_DATABASE:
                return None
            med = MEDICINE_DATABASE[med_key]

            # Allergy block
            for a in patient_allergies:
                if any(a in al.lower() for al in med['allergies']):
                    return None

            # Child safety block
            if age < 12 and med['child_dose'] == 0:
                return None

            # Dose by age
            if age < 12:
                dose = med['child_dose'] if med['child_dose'] > 0 else med['adult_dose'] * 0.5
            elif age > 65:
                dose = med['elderly_dose']
            else:
                dose = med['adult_dose']

            # Clean pharmaceutical rounding
            if dose >= 100:
                dose = round(dose / 50) * 50
            elif dose >= 10:
                dose = round(dose / 5) * 5
            else:
                dose = round(dose)
            dose = int(dose)

            times = min(3, int(med['max_daily'] / dose)) if dose > 0 else 1
            times = max(1, times)

            ftl = med['food_take'].lower()
            food_short = "Before meal" if ('empty' in ftl or 'before' in ftl) else "After meal"

            if times == 1:
                schedule = [{"time": "Morning", "icon": "🌅", "clock": "8:00 AM", "dose": dose, "note": food_short}]
            elif times == 2:
                schedule = [
                    {"time": "Morning", "icon": "🌅", "clock": "8:00 AM", "dose": dose, "note": food_short},
                    {"time": "Night",   "icon": "🌙", "clock": "9:00 PM", "dose": dose, "note": food_short},
                ]
            else:
                schedule = [
                    {"time": "Morning",   "icon": "🌅", "clock": "8:00 AM",  "dose": dose, "note": food_short},
                    {"time": "Afternoon", "icon": "☀️", "clock": "2:00 PM", "dose": dose, "note": food_short},
                    {"time": "Night",     "icon": "🌙", "clock": "9:00 PM",  "dose": dose, "note": food_short},
                ]

            proto = DISEASE_PROTOCOLS.get(for_disease, {})
            return {
                "medicine":      med['name'],
                "category":      med['category'],
                "for_disease":   for_disease.title(),
                "dose":          dose,
                "times_per_day": times,
                "max_daily":     int(med['max_daily']),
                "food_timing":   med['food_take'],
                "food_avoid":    med['food_avoid'],
                "schedule":      schedule,
                "side_effects":  med['side_effects'],
                "duration":      proto.get('duration', '3-5 days'),
                "duration_note": proto.get('duration_note', ''),
                "diet":          proto.get('diet', ''),
                "diet_avoid":    proto.get('avoid', ''),
            }

        # ── Build medicines for ALL detected diseases (max 3) ──────────────
        medicines_out = []
        seen_keys     = []
        all_diagnoses = []

        for dk in detected_diseases[:3]:
            proto = DISEASE_PROTOCOLS.get(dk, DISEASE_PROTOCOLS['fever'])
            all_diagnoses.append(proto['diagnosis'])
            for med_name in proto.get('medicines', ['paracetamol']):
                mk = med_name.lower().strip()
                if mk in seen_keys:
                    continue
                entry = build_med_entry(mk, dk)
                if entry:
                    seen_keys.append(mk)
                    medicines_out.append(entry)
                    break  # one medicine per disease

        if not medicines_out:
            return jsonify({"error": "Could not find suitable medicines. Please consult a doctor."})

        # ── Combined diagnosis label ───────────────────────────────────────
        combined_diagnosis = " + ".join([d.title() for d in detected_diseases[:3]])
        primary_protocol   = DISEASE_PROTOCOLS.get(detected_diseases[0], DISEASE_PROTOCOLS['fever'])

        # ── Special instructions (combined across all medicines) ───────────
        special = []
        for entry in medicines_out:
            fa = entry['food_avoid'].lower()
            ft = entry['food_timing'].lower()
            if 'alcohol' in fa:
                special.append(f"🚫 Avoid alcohol — especially with {entry['medicine']}")
            if 'grapefruit' in fa:
                special.append(f"🍊 Avoid grapefruit juice with {entry['medicine']}")
            if 'empty' in ft or 'before' in ft:
                special.append(f"🍽️ {entry['medicine']}: Take on empty stomach, 30 min before food")
            if 'antibiotic' in entry['category'].lower():
                special.append(f"⚠️ {entry['medicine']}: Complete the FULL course even if you feel better")
        special.append("💧 Drink a full glass of water (200ml) with each dose")
        special.append("⏰ Take medicines at the same time every day")
        special.append("📋 Do not stop any medication without consulting your doctor")

        # Remove duplicates
        special = list(dict.fromkeys(special))

        # ── Combined diet advice ───────────────────────────────────────────
        all_diet   = " | ".join([e['diet']       for e in medicines_out if e.get('diet')])
        all_avoid  = " | ".join([e['diet_avoid']  for e in medicines_out if e.get('diet_avoid')])

        return jsonify({"prescription": {
            "diagnosis":            combined_diagnosis,
            "diagnosis_detail":     f"AI detected {len(detected_diseases)} condition(s): " + ", ".join([d.title() for d in detected_diseases]),
            "patient_problem":      problem,
            "age_group":            age_group,
            "medicines":            medicines_out,
            "duration":             medicines_out[0]['duration'],
            "duration_note":        medicines_out[0]['duration_note'],
            "food_timing":          medicines_out[0]['food_timing'],
            "food_avoid":           medicines_out[0]['food_avoid'],
            "special_instructions": special,
            "doctor_advice":        primary_protocol.get('advice', []),
            "diet_advice":          all_diet,
            "diet_avoid":           all_avoid,
            "side_effects":         medicines_out[0]['side_effects'],
            "date":                 datetime.datetime.now().strftime("%A, %d %B %Y"),
        }})

    except Exception as e:
        return jsonify({"error": str(e)})


# ── Chatbot (Separate Page) ────────────────────────────

@app.route('/chatbot')
def chatbot_page():
    if 'user' not in session:
        return redirect(url_for('login_page'))
    medicine_list = sorted(MEDICINE_DATABASE.keys())
    return render_template('chatbot.html', medicines=medicine_list, user=session.get('user'))


@app.route('/chatbot_ask', methods=['POST'])
def chatbot_ask():
    """Open AI chatbot — answers ANY health question. No preset limits."""
    try:
        data     = request.get_json()
        question = data.get('question', '').strip()
        medicine = data.get('medicine', '').lower().strip()

        if not question:
            return jsonify({"answer": "Please type a question."})

        q   = question.lower()
        med = MEDICINE_DATABASE.get(medicine) if medicine in MEDICINE_DATABASE else None
        mn  = med['name'] if med else None

        # ── Medicine-specific questions ──────────────────
        if med:
            if any(k in q for k in ['side effect', 'side-effect', 'adverse', 'reaction', 'side effects']):
                ans = f"**Side effects of {mn}:**\n{med['side_effects']}\n\nIf you experience severe reactions like difficulty breathing, severe rash or chest pain — contact your doctor or go to emergency immediately."

            elif any(k in q for k in ['food', 'eat', 'diet', 'drink', 'avoid eating', 'avoid drinking']):
                ans = f"**Food guidance for {mn}:**\n\n🚫 **Avoid:** {med['food_avoid']}\n\n✅ **How to take:** {med['food_take']}\n\nFollowing these food rules improves the medicine's effectiveness and reduces side effects."

            elif any(k in q for k in ['dose', 'dosage', 'how much', 'mg', 'amount', 'quantity']):
                ans = (f"**Dosage of {mn}:**\n"
                       f"• Adult: {med['adult_dose']}mg\n"
                       f"• Child (under 12): {med['child_dose']}mg {'(Not recommended for children)' if med['child_dose']==0 else ''}\n"
                       f"• Elderly (over 65): {med['elderly_dose']}mg\n"
                       f"• Maximum per day: {med['max_daily']}mg\n\n"
                       f"Never exceed the maximum daily dose. Always follow your doctor's prescription.")

            elif any(k in q for k in ['interact', 'combine', 'together with', 'mix', 'other medicine', 'with other drug']):
                ans = (f"**{mn} drug interactions:**\n"
                       f"Do not take {mn} with: {', '.join(med['interactions'])}\n\n"
                       f"Always tell your doctor and pharmacist ALL medicines you are currently taking, including supplements and herbal remedies.")

            elif any(k in q for k in ['use', 'for what', 'treat', 'what is', 'purpose', 'indication', 'prescribed for']):
                use_clean = med['use'].replace('|', ', ')
                ans = f"**{mn} — What is it used for?**\n{use_clean}\n\n**Category:** {med['category']}"

            elif any(k in q for k in ['allerg', 'allergic', 'avoid if', 'who should not']):
                ans = (f"**{mn} — Allergy information:**\n"
                       f"Do NOT take {mn} if you are allergic to: {', '.join(med['allergies'])}\n\n"
                       f"**Conditions to avoid it:** {', '.join(med['conditions_avoid'])}\n\n"
                       f"If you experience throat swelling, difficulty breathing or severe rash after taking it — seek emergency care immediately.")

            elif any(k in q for k in ['store', 'storage', 'keep', 'refrigerate']):
                ans = (f"**Storing {mn}:**\n"
                       f"• Store below 25°C in a cool, dry place\n"
                       f"• Keep away from direct sunlight and humidity\n"
                       f"• Keep out of reach of children\n"
                       f"• Do not use after the expiry date on the pack\n"
                       f"• Some medicines (like Insulin) require refrigeration — check the label")

            elif any(k in q for k in ['pregnan', 'breastfeed', 'nursing', 'pregnancy', 'baby', 'lactation']):
                ans = (f"**{mn} and pregnancy/breastfeeding:**\n"
                       f"ALWAYS consult your doctor before taking {mn} if you are pregnant, planning pregnancy, or breastfeeding. Many medicines cross the placenta or pass into breast milk and can affect the baby.\n\n"
                       f"Do not self-medicate during pregnancy. Your doctor will weigh the benefit vs. risk.")

            elif any(k in q for k in ['overdose', 'too much', 'excess', 'took extra']):
                ans = (f"**{mn} overdose:**\n"
                       f"The maximum safe dose is {med['max_daily']}mg per day.\n\n"
                       f"🚨 If you suspect an overdose:\n"
                       f"• Call 108 (emergency) immediately\n"
                       f"• Do NOT induce vomiting unless instructed by a doctor\n"
                       f"• Take the medicine pack with you to the hospital")

            elif any(k in q for k in ['when to take', 'morning', 'night', 'timing', 'schedule', 'time of day']):
                ans = (f"**When to take {mn}:**\n"
                       f"{med['food_take']}\n\n"
                       f"Taking medicine at the same time every day maintains steady blood levels and improves effectiveness. Set a daily alarm if needed.")

            elif any(k in q for k in ['safe', 'danger', 'risk', 'harmful', 'is it okay']):
                ans = (f"**Safety profile of {mn}:**\n"
                       f"{mn} is generally safe when taken as prescribed. Key safety points:\n"
                       f"• Do not use if allergic to: {', '.join(med['allergies'])}\n"
                       f"• Caution with: {', '.join(med['interactions'])[:80]}...\n"
                       f"• Avoid if you have: {', '.join(med['conditions_avoid'][:2])}\n\n"
                       f"Always inform your doctor about all your health conditions before starting this medicine.")

            elif any(k in q for k in ['summary', 'everything', 'full detail', 'tell me all', 'complete info']):
                use_clean = med['use'].replace('|', ', ')
                ans = (f"**Complete Information — {mn}:**\n\n"
                       f"📋 **Use:** {use_clean}\n"
                       f"🏷️ **Category:** {med['category']}\n"
                       f"💊 **Adult dose:** {med['adult_dose']}mg | Max/day: {med['max_daily']}mg\n"
                       f"🍽️ **Take:** {med['food_take']}\n"
                       f"🚫 **Avoid:** {med['food_avoid']}\n"
                       f"⚠️ **Side effects:** {med['side_effects']}\n"
                       f"🔄 **Interactions:** {', '.join(med['interactions'])}\n"
                       f"🚑 **Allergies/Avoid if:** {', '.join(med['allergies'])}")
            else:
                # Open question about the selected medicine
                use_clean = med['use'].replace('|', ', ')
                ans = (f"You asked about **{mn}**: \"{question}\"\n\n"
                       f"Here's what I know:\n"
                       f"• **Used for:** {use_clean}\n"
                       f"• **Adult dose:** {med['adult_dose']}mg | Max {med['max_daily']}mg/day\n"
                       f"• **Take:** {med['food_take']}\n"
                       f"• **Avoid:** {med['food_avoid']}\n\n"
                       f"Ask me more specifically: dosage, food, side effects, interactions, storage, pregnancy, overdose, or safety!")

        # ── General health questions (no medicine selected) ──
        else:
            if any(k in q for k in ['fever', 'temperature', 'pyrexia', 'body heat']):
                ans = ("**Fever guidance:**\n"
                       "• Below 38°C: Rest and fluids — no medicine needed\n"
                       "• 38–39°C: Paracetamol 500–1000mg every 6 hours\n"
                       "• Above 39.5°C: See a doctor urgently\n"
                       "• Above 40°C or fever in infant under 3 months: Emergency care\n\n"
                       "Drink 2–3 litres of water daily. Tepid sponging helps reduce temperature.")

            elif any(k in q for k in ['blood pressure', 'hypertension', 'bp high', 'high bp']):
                ans = ("**High Blood Pressure guidance:**\n"
                       "• Normal: Below 120/80 mmHg\n"
                       "• High: 140/90 or above — needs treatment\n"
                       "• Crisis: 180/120 or above — emergency care\n\n"
                       "Common medicines: Amlodipine, Atenolol, Losartan, Lisinopril\n"
                       "Lifestyle: Reduce salt, exercise 30 min daily, quit smoking, limit alcohol")

            elif any(k in q for k in ['diabetes', 'blood sugar', 'sugar level', 'diabetic']):
                ans = ("**Diabetes guidance:**\n"
                       "• Normal fasting sugar: 70–100 mg/dL\n"
                       "• Diabetes: Fasting >126 mg/dL\n"
                       "• First-line medicine: Metformin 500mg with meals\n\n"
                       "Monitor sugar daily. HbA1c target: below 7%. Exercise 30–45 min daily.\n"
                       "🚨 Sugar below 70 (hypoglycemia): Take glucose/sugar immediately")

            elif any(k in q for k in ['headache', 'migraine', 'head pain']):
                ans = ("**Headache / Migraine guidance:**\n"
                       "• Mild headache: Paracetamol 500mg (safest)\n"
                       "• Tension headache: Ibuprofen 400mg with food\n"
                       "• Migraine: Take medicine at very first sign, rest in dark room\n\n"
                       "🚨 Sudden severe 'thunderclap' headache — seek emergency care (could be serious)")

            elif any(k in q for k in ['antibiotic', 'amoxicillin', 'azithromycin', 'ciprofloxacin']):
                ans = ("**Antibiotic guidance:**\n"
                       "• Only take antibiotics prescribed by a doctor\n"
                       "• Always COMPLETE the full course — never stop early even if you feel better\n"
                       "• Do not share antibiotics with others\n"
                       "• Take with food to reduce stomach upset\n"
                       "• Take probiotics (curd/yogurt) to protect gut bacteria\n"
                       "• Avoid alcohol — reduces effectiveness")

            elif any(k in q for k in ['stomach', 'acidity', 'heartburn', 'acid', 'gastric', 'indigestion']):
                ans = ("**Acidity / Heartburn guidance:**\n"
                       "• Omeprazole 20mg before breakfast (PPI — best for acid)\n"
                       "• Antacids (Gelusil, Digene) for immediate relief after meals\n"
                       "• Eat smaller, more frequent meals\n"
                       "• Avoid: Spicy food, coffee, alcohol, lying down after eating\n"
                       "• Elevate head of bed if nighttime reflux")

            elif any(k in q for k in ['cold', 'flu', 'runny nose', 'sore throat', 'sneezing']):
                ans = ("**Cold / Flu guidance:**\n"
                       "• Antihistamine: Cetirizine 10mg once daily for runny nose\n"
                       "• Paracetamol for fever and body ache\n"
                       "• Steam inhalation 2–3 times daily\n"
                       "• Warm salt water gargling for sore throat\n"
                       "• Rest and drink warm fluids\n"
                       "• Antibiotics NOT needed for viral cold")

            elif any(k in q for k in ['allerg', 'rash', 'itch', 'hives', 'urticaria']):
                ans = ("**Allergy / Rash guidance:**\n"
                       "• Mild allergy: Cetirizine 10mg or Loratadine 10mg once daily\n"
                       "• Skin rash: Hydrocortisone cream + antihistamine\n"
                       "• Identify and avoid the allergen\n\n"
                       "🚨 Anaphylaxis warning signs: difficulty breathing, throat swelling, fainting — call 108 IMMEDIATELY")

            elif any(k in q for k in ['sleep', 'insomnia', 'cant sleep', 'not sleeping']):
                ans = ("**Sleep / Insomnia guidance:**\n"
                       "• Fix sleep schedule — same time every night\n"
                       "• No screens (phone/TV) 1 hour before bed\n"
                       "• Dark, cool room aids sleep\n"
                       "• Melatonin 0.5–5mg short-term for jet lag or shift workers\n"
                       "• 🚫 Sleeping pills: Only under medical supervision — risk of dependence")

            elif any(k in q for k in ['pain', 'painkiller', 'ache', 'joint pain', 'body pain']):
                ans = ("**Pain relief guidance:**\n"
                       "• Mild pain: Paracetamol 500–1000mg (safest first choice)\n"
                       "• Inflammation/joint pain: Ibuprofen 400mg with food\n"
                       "• 🚫 Never take ibuprofen on empty stomach or if you have kidney issues\n"
                       "• Neuropathic pain: Needs prescription (Gabapentin, Amitriptyline)\n"
                       "• Severe or chronic pain: Always consult a doctor")

            elif any(k in q for k in ['vitamin', 'deficiency', 'supplement', 'iron', 'calcium', 'b12', 'vitamin d']):
                ans = ("**Vitamin & Supplement guidance:**\n"
                       "• Vitamin D: 1000–2000 IU daily (take with fatty food)\n"
                       "• Vitamin B12: 500–1000 mcg daily (important for vegetarians)\n"
                       "• Iron: 100mg daily with Vitamin C — avoid with tea/dairy/calcium\n"
                       "• Calcium: 500mg twice daily with food\n"
                       "• Test your blood levels before supplementing — over-supplementation can be harmful")

            elif any(k in q for k in ['hi', 'hello', 'hey', 'good morning', 'namaste', 'help me']):
                ans = ("👋 Hello! I'm your **MediSafe AI Health Assistant**.\n\n"
                       "I can answer ANY health question you have:\n"
                       "• Select a medicine from the list → ask about dosage, food, side effects, interactions\n"
                       "• General health topics: fever, BP, diabetes, headache, stomach, cold, allergy, pain, vitamins\n"
                       "• Medicine safety, storage, pregnancy, overdose guidance\n\n"
                       "Just type your question — no preset options needed!")

            else:
                # TRULY OPEN-ENDED - Answer ANY health question!
                ans = f"💡 **About your question:** \"{question}\"\n\n"
                
                # Analyze keywords and give relevant response
                if any(word in q for word in ['pain', 'hurt', 'ache', 'sore']):
                    ans += "For pain relief: Paracetamol 500mg or Ibuprofen 400mg after food. Don't exceed max daily dose. If severe or persistent, consult doctor.\n\n"
                
                if any(word in q for word in ['cough', 'throat']):
                    ans += "For cough: Warm water + honey + lemon. Avoid cold drinks. If persistent >2 weeks, see doctor.\n\n"
                
                if any(word in q for word in ['sleep', 'insomnia']):
                    ans += "For sleep: Avoid caffeine after 4 PM. Maintain regular sleep schedule. If chronic insomnia, consult doctor (may prescribe Zolpidem/Melatonin).\n\n"
                
                if any(word in q for word in ['vomit', 'nausea']):
                    ans += "For nausea/vomiting: Ondansetron 4mg. Stay hydrated. Small frequent meals. If severe or blood in vomit, emergency care.\n\n"
                
                if any(word in q for word in ['diarrhea', 'loose motion']):
                    ans += "For diarrhea: ORS solution frequently. Probiotics. Light diet (rice, banana). If >3 days or blood in stool, see doctor.\n\n"
                
                if any(word in q for word in ['constipation']):
                    ans += "For constipation: Increase fiber (fruits, vegetables). Drink 2-3L water daily. Isabgol/Psyllium husk. If persistent, Lactulose syrup.\n\n"
                
                if any(word in q for word in ['anxiety', 'stress', 'worry']):
                    ans += "For anxiety: Deep breathing exercises. Regular exercise. If severe, consult doctor (may prescribe SSRI/Benzodiazepines).\n\n"
                
                # If none of the above matched, give general health advice
                if ans == f"💡 **About your question:** \"{question}\"\n\n":
                    ans += ("Based on your question, here's general medical advice:\n\n"
                           "1. **Rest** - Give your body time to heal\n"
                           "2. **Hydration** - Drink 2-3L water daily\n"
                           "3. **Nutrition** - Eat balanced meals\n"
                           "4. **Monitor** - Track your symptoms\n"
                           "5. **Consult** - See doctor if symptoms worsen or persist\n\n"
                           "For specific medicine recommendations, describe your symptoms in detail or select a medicine from the panel.")
                
                ans += "\n💊 I can answer ANY health question - just ask!"

        return jsonify({"answer": ans})

    except Exception as e:
        return jsonify({"answer": f"Error: {str(e)}"})


# ── Legacy chatbot endpoint (result.html uses /chatbot_ask now) ─
# This is kept ONLY so any old bookmarked POST calls still work
@app.route('/chatbot_legacy', methods=['POST'])
def chatbot_legacy():
    return chatbot_ask()


# ── Misc routes ────────────────────────────────────────

@app.route('/search_medicine', methods=['POST'])
def search_medicine():
    try:
        data  = request.get_json()
        query = data.get('query', '').lower().strip()
        if len(query) < 2: return jsonify({"results": []})
        results = [{'key': k, 'name': m['name'], 'category': m['category']}
                   for k, m in MEDICINE_DATABASE.items()
                   if query in k or query in m['name'].lower()]
        return jsonify({"results": results[:10]})
    except Exception as e:
        return jsonify({"results": [], "error": str(e)})


@app.route('/api/medicines')
def api_medicines():
    return jsonify(sorted(MEDICINE_DATABASE.keys()))

@app.route('/api/stats')
def api_stats():
    categories = {}
    for med in MEDICINE_DATABASE.values():
        cat = med.get('category', 'Other')
        categories[cat] = categories.get(cat, 0) + 1
    return jsonify({"total_medicines": len(MEDICINE_DATABASE), "categories": categories,
                    "generated_at": datetime.datetime.now().isoformat()})


@app.errorhandler(404)
def page_not_found(e): return render_template('errors/404.html'), 404

@app.errorhandler(500)
def internal_error(e): return render_template('errors/500.html'), 500


if __name__ == '__main__':
    print(f"✅ MediSafe AI ready — {len(MEDICINE_DATABASE)} medicines loaded")
    print("🌐 Open: http://localhost:5000")
    app.run(debug=True, host='0.0.0.0', port=5000)
