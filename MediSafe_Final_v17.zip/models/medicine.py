"""
MediSafe AI — Medicine Model
=============================
Data model and schema for a Medicine entity.
"""

from dataclasses import dataclass, field
from typing import List, Optional


@dataclass
class Medicine:
    """Represents a single medicine entry from the database."""
    name:          str
    category:      str
    use:           str
    adult_dose:    float
    child_dose:    float
    elderly_dose:  float
    max_daily:     float
    side_effects:  str
    interactions:  str
    contraindications: str
    food_avoid:    str
    food_take:     str
    allergy_warning: str = ""

    # Computed
    @property
    def key(self) -> str:
        return self.name.lower().strip()

    @property
    def use_list(self) -> List[str]:
        return [u.strip() for u in self.use.split('|')]

    @property
    def interaction_list(self) -> List[str]:
        return [i.strip() for i in self.interactions.split(',') if i.strip()]

    @property
    def contraindication_list(self) -> List[str]:
        return [c.strip() for c in self.contraindications.split(',') if c.strip()]

    def to_dict(self) -> dict:
        return {
            "name":             self.name,
            "category":         self.category,
            "use":              self.use,
            "adult_dose":       self.adult_dose,
            "child_dose":       self.child_dose,
            "elderly_dose":     self.elderly_dose,
            "max_daily":        self.max_daily,
            "side_effects":     self.side_effects,
            "interactions":     self.interactions,
            "contraindications":self.contraindications,
            "food_avoid":       self.food_avoid,
            "food_take":        self.food_take,
            "allergy_warning":  self.allergy_warning,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'Medicine':
        return cls(
            name           = data.get('name', ''),
            category       = data.get('category', ''),
            use            = data.get('use', ''),
            adult_dose     = float(data.get('adult_dose', 0)),
            child_dose     = float(data.get('child_dose', 0)),
            elderly_dose   = float(data.get('elderly_dose', 0)),
            max_daily      = float(data.get('max_daily', 0)),
            side_effects   = data.get('side_effects', ''),
            interactions   = data.get('interactions', ''),
            contraindications = data.get('contraindications', ''),
            food_avoid     = data.get('food_avoid', ''),
            food_take      = data.get('food_take', ''),
            allergy_warning= data.get('allergy_warning', ''),
        )


@dataclass
class Patient:
    """Represents a patient check request."""
    name:         str
    age:          int
    weight:       float
    gender:       str
    disease:      str
    current_meds: str        = ""
    allergies:    str        = ""
    conditions:   str        = ""

    @property
    def age_group(self) -> str:
        if self.age < 12:    return "child"
        if self.age > 65:    return "elderly"
        return "adult"

    @property
    def current_meds_list(self) -> List[str]:
        return [m.strip().lower() for m in self.current_meds.split(',') if m.strip()]

    @property
    def allergies_list(self) -> List[str]:
        return [a.strip().lower() for a in self.allergies.split(',') if a.strip()]

    @property
    def conditions_list(self) -> List[str]:
        return [c.strip().lower() for c in self.conditions.split(',') if c.strip()]


@dataclass
class SafetyResult:
    """Result of a medicine safety check."""
    is_safe:              bool
    status:               str
    status_class:         str
    medicine:             str
    category:             str
    use:                  str
    patient_name:         str
    age_category:         str
    dosage:               float
    max_daily:            float
    side_effects:         str
    food_avoid:           str
    food_take:            str
    explanation:          str
    safety_score:         int           = 100
    interaction_warnings: List[dict]    = field(default_factory=list)
    condition_warnings:   List[dict]    = field(default_factory=list)
